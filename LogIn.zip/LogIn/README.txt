#                                                 #
#             Test Automation Archetype           #
#                                                 #


** This sample application shows the usage of the BMW Agile Test Automation Platform **
***************************************************************************************
The sample application which will be used can be found under: https://loplistapp-atc-dev.mp-dev-cnap.bmwgroup.net/loplist/index.jsp#


1. Enter your valid token that you received by the ATC team into...
2. Execute 'mvn clean verify' and the tests should 
3. You are ready to modify the test automation project to your own needs
