package acceptancetests.pages;

import acceptancetests.base.DriverUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class CreditReviewLong extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(CreditreviewPage.class);

    public CreditReviewLong(WebDriver driver) {
        super(driver);
    }
    //..........................................................................................//
    //................................Step30-CRSP-E2E_IF........................................//
    //................................Credit Review Long........................................//
    
    // select the credit Review ISU Level Long
    @FindBy(how=How.ID, using="credit_review_drop_down")
    private WebElement Click_dropdownLonglevel;
    // Select the confirm documentation
    @FindBy(how=How.ID, using="button_confirm_kwg_18")
    private WebElement  Click_confirmdocumentationlong;
    // Select Documenation 
    @FindBy(how=How.LINK_TEXT,using="Documentation �18 KWG")
    private WebElement Click_documentationkwg;
    // Select the other comments
    @FindBy(how=How.LINK_TEXT,using="Other Comments")
    private WebElement Click_othercomments;
    // Select logout
    @FindBy(how=How.ID,using="navigation.usernav.username")
    private WebElement Click_logoutandcloseapplication;
    //Select Go back
    @FindBy(how=How.ID, using="navigation.MENU_client.labelKey")
    private WebElement Click_goback;
    //Select print long term
    @FindBy(how=How.ID, using="falseprint_button")
    private WebElement Click_printlongterm;
    // Select the Credit Review ISU Level Long
    public void Click_DropDownLongLevel() {//id:credit_review_drop_down
    	if (DriverUtil.isChrome()) {
    		Select dateDropDown=new Select(driver.findElement(By.id("credit_review_drop_down")));
 		      dateDropDown.selectByIndex(01);     		
    	}
    	
    }
    //I Select the item of the credit Review Long from DropDownList
    // this in credit reviewPage is the same function 
   
    // Select the primary ISU
    public void Click_ItemPrimaryISU() {
    	if(DriverUtil.isChrome()) {
    		Select dateDropDown=new Select(driver.findElement(By.id("credit_review_primary_business_line_drop_down")));
		      dateDropDown.selectByIndex(02); 
    	}
    }
    // Select Documentation Without German Bancking
    public void Click_DocumenationWithoutGermanBanking() {
    	if(DriverUtil.isChrome()) {
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Documentation �18 KWG")));
    	}
    	Click_documentationkwg.click();
   	 // Select the dropdown list from ISU with id:selected_ise_cb_names
   	 Select dateDropDown=new Select(driver.findElement(By.id("selected_ise_cb_names")));
        dateDropDown.selectByIndex(1);
        //id:member_evaluated_documents
        dateDropDown=new Select(driver.findElement(By.id("member_evaluated_documents")));
        dateDropDown.selectByIndex(01);
     // id:credit_review_kwg_18_kwg_erfuellt
        //dateDropDown=new Select(driver.findElement(By.id("credit_review_kwg_18_kwg_erfuellt")));
       // dateDropDown.selectByIndex(03);
    }
    // Select confirm to Documentation 18KWG
    public void Click_ConfirmDocumentationLong() {
    	if(DriverUtil.isChrome()) {
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("button_confirm_kwg_18")));
    	}
    	Click_confirmdocumentationlong.click();
    }
    // Select Not Fulfilled
    public void Click_DocumenationFullfilledGermanBanking() {
    	if(DriverUtil.isChrome()) {
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Documentation �18 KWG")));
    	}
    	Click_documentationkwg.click();
   	 // Select the dropdown list from ISU with id:selected_ise_cb_names
   	 Select dateDropDown=new Select(driver.findElement(By.id("selected_ise_cb_names")));
        dateDropDown.selectByIndex(1);
        //id:member_evaluated_documents
        dateDropDown=new Select(driver.findElement(By.id("member_evaluated_documents")));
        dateDropDown.selectByIndex(01);
     // id:credit_review_kwg_18_kwg_erfuellt
        dateDropDown=new Select(driver.findElement(By.id("credit_review_kwg_18_kwg_erfuellt")));
        dateDropDown.selectByIndex(03);
     }
     // Select the Other Comments
    	public void Click_OtherCommentsLong() {
    		if(DriverUtil.isChrome()) {
        		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Other Comments")));
        	}
    		Click_othercomments.click();
    		WebElement Text_Fill = driver.findElement(By.id("credit_review_other_comment_comment"));
    		Text_Fill.sendKeys(".......................................................The New Information/New Comments................");
     }
    // Select LogOut
    	public void Click_LogOutAndCloseApplication() {
    		if(DriverUtil.isChrome()) {
        		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("navigation.usernav.username")));
        	}
    		Click_logoutandcloseapplication.click();
    		Actions logout_click =new Actions(driver);
    		logout_click.sendKeys(Keys.TAB).build().perform();
    		logout_click.sendKeys(Keys.ENTER).build().perform();
    	}
    	// Select the ID to Finalize
    	public void Click_InternalIDTOFinalize() {
    		if(DriverUtil.isChrome()) {
    			Actions Select_ID = new Actions(driver);
    			for(int i=0;i<23;i++)
    				Select_ID.sendKeys(Keys.TAB).build().perform();
    			Select_ID.sendKeys(Keys.ENTER).build().perform();
    		}
    		
    	}
       // Select Finalize
    	public void Click_FinalizeISULong() {
    		driver.findElement(By.id("credit_review_approve_button")).click();
    		}
    	// Select Go Back
    	public void Click_GoBack() {
    		if(DriverUtil.isChrome()) {//id: navigation.MENU_client.labelKey.Click_goback
    			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("navigation.MENU_client.labelKey")));
        	}
    		Click_goback.click();
    		}
    		//falseprint_button
    	public void Click_PrintLongTerm() {
    		if(DriverUtil.isChrome()) {//id: falseprint_button.Click_printlongterm
    			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("falseprint_button")));
        	}
    		Click_printlongterm.click();
    		}
    	
    		//............................................................................................................................//
    	//................................................................................................................................//
    	//.......................................................................................................................................//
    	@FindBy(how = How.ID, using = "username")
 	    private WebElement usernameTextField2;
 	    @FindBy(how = How.ID, using = "password")
 	    private WebElement passwordTextField2;
 	    @FindBy(how=How.ID,using="rating_save_button")
 	    private WebElement Click_saveratingmodel;
 	   
    	public void Click_SaveRatingModel() {
    		if(DriverUtil.isChrome()) {//id: rating_save_button
    			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("rating_save_button")));
    		}
    		Click_saveratingmodel.click();
 	   }
    	
    	public void Click_ClickAndNewTab(){
    		if(DriverUtil.isChrome()) {
    			// Open new tab
    			((JavascriptExecutor)driver).executeScript("window.open()"); 
    			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
    			driver.switchTo().window(tabs2.get(1));
    			// open new url
    			driver.get("https://crsp-i.bmwgroup.net/crsp/login");
    		}
        	}
    		// enter new user and new password 
    	
    		public boolean checkUsername2(String username2) {
            if (DriverUtil.isChrome()) {
                waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
            }
            return usernameTextField2.getText().equals(username2);
           }
    		//@AM: get the variable and send keys
    		public void enterUsername2(String username2) {
            usernameTextField2.clear();
            usernameTextField2.sendKeys(username2);
    		}
        
    		public boolean checkPassword2(String password2) {
            if (DriverUtil.isChrome()) {
                waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
            }
            return passwordTextField2.getText().equals(password2);
    		}
    		public void enterPassword2(String password2) {
    			passwordTextField2.clear();
    			passwordTextField2.sendKeys(password2);
    		}
    		// Select the Same Rating
    		public void Click_OpenSameRating() {
        	  if (DriverUtil.isChrome()) {
        		  Actions new_tab = new Actions(driver);
        		  for(int i=0;i<23;i++)
        			  new_tab.sendKeys(Keys.TAB).build().perform();
        		  new_tab.sendKeys(Keys.ENTER).build().perform();
        	  }
        	  ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
  			  driver.switchTo().window(tabs2.get(0));
        	  
    		}
    		//User 1 closes the rating template
    		public void Click_CloseUser1RatingTemplate() {
    			if (DriverUtil.isChrome()) {
    				Actions new_tab = new Actions(driver);
    				for(int i=0;i<15;i++)
          			  new_tab.sendKeys(Keys.TAB).build().perform();
          		  new_tab.sendKeys(Keys.ENTER).build().perform();
          		  
    			}
    			
    		}
    		// 6 minutes later the user2 open the same rating
    		public void Click_User2ClickSameRating() {
    			if (DriverUtil.isChrome()) {
    				
    				//driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
    			
    				//WebDriverWait wait = new WebDriverWait(driver,60);
    				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
    	  			  driver.switchTo().window(tabs2.get(1));
    			}
    		}
    		// Refresh Page of user 2
    		public void Click_User2ClickRefresh() {
    			if (DriverUtil.isChrome()) {
    				
    				driver.navigate().refresh();
    				driver.get("https://crsp-i.bmwgroup.net/crsp/login");
    			}
    		}
    		// User 1 open same rating
    		public void Click_User1Clicksamerating() {
    			if (DriverUtil.isChrome()) {
    				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
  	  			  driver.switchTo().window(tabs2.get(0));
    			}
    		}
    		//....................................................................................................................................................//
    		//....................................................................................................................................................//
    		//....................................................................................................................................................//
    		
    		
    		@FindBy(how=How.LINK_TEXT, using="Credit Review")
    		private WebElement Click_creditreviewnotification;
    		@FindBy(how=How.ID, using="new_credit_reviewWrapper")
    		private WebElement Click_newcreditreviewnotification;
    		
    		// I select the ISU of credit Review in CRSP-i
    		//I Select ISU as the customer Type of New Credit Review Notification
    		public void Click_NewISUOfCreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				Actions New_ISU = new Actions(driver);
    				for(int i=0;i<27;i++)
    					New_ISU.sendKeys(Keys.TAB).build().perform();
    				New_ISU.sendKeys(Keys.ENTER).build().perform();
    				New_ISU.sendKeys(Keys.DOWN).build().perform();
    				New_ISU.sendKeys(Keys.DOWN).build().perform();
    				New_ISU.sendKeys(Keys.DOWN).build().perform();
    				New_ISU.sendKeys(Keys.DOWN).build().perform();
    				New_ISU.sendKeys(Keys.DOWN).build().perform();
    				New_ISU.sendKeys(Keys.ENTER).build().perform();
    			}
    		}
    		// I Select the Credit Review In CRSP-i
    		public void Click_CreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Credit Review")));
    			}
    			Click_creditreviewnotification.click();
    		}
    		// I Select the item of the credit Review Notification
    		public void Click_ItemOfCreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				Actions tab_item = new Actions(driver);
    				for(int i=0;i<4;i++)
    					tab_item.sendKeys(Keys.TAB).build().perform();
    				tab_item.sendKeys(Keys.ENTER).build().perform();
    				tab_item.sendKeys(Keys.DOWN).build().perform();
    				tab_item.sendKeys(Keys.ENTER).build().perform();
    		}
    		}
    		// I Select the item of primary Credit Review
    		public void Click_ItemOfPrimaryCreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				Actions tab_item1 = new Actions(driver);
    				for(int i=0;i<5;i++)
    					tab_item1.sendKeys(Keys.TAB).build().perform();
    				tab_item1.sendKeys(Keys.ENTER).build().perform();
    				tab_item1.sendKeys(Keys.DOWN).build().perform();
    				tab_item1.sendKeys(Keys.DOWN).build().perform();
    				tab_item1.sendKeys(Keys.ENTER).build().perform();
    			}
    		}
    		// I Click to New Credit Review Notification
    		public void Click_NewCreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				Actions tab_new = new Actions(driver);
    				for(int i=0;i<10;i++)
    					tab_new.sendKeys(Keys.TAB).build().perform();
    				tab_new.sendKeys(Keys.ENTER).build().perform();
    			}
    		}
    		// Save the credit Review 
    		public void Click_SaveNewCreditReviewNotification() {
    			if (DriverUtil.isChrome()) {
    				Actions tab_save = new Actions(driver);
    				
    				tab_save.sendKeys(Keys.TAB).build().perform();
    				tab_save.sendKeys(Keys.TAB).build().perform();
    				tab_save.sendKeys(Keys.ENTER).build().perform();
    			}
    		}
    		// I Open a new Window in chrome or firefox
    		public void Click_NewTabWindow() {
    			if (DriverUtil.isChrome()) {
    				((JavascriptExecutor)driver).executeScript("window.open()"); 
    				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
        			driver.switchTo().window(tabs2.get(1));
        			// open new url
        			driver.get("https://crsp-i.bmwgroup.net/crsp/login");
    				
    			}    			
    		}
    		// User 2 open CRSP
    		public void Click_SelectSameRatingModelOfUserOne() {
    			if (DriverUtil.isChrome()) {
    				Actions tab_save = new Actions(driver);
    				for(int i=0;i<36;i++)
    				tab_save.sendKeys(Keys.TAB).build().perform();
    				tab_save.sendKeys(Keys.ENTER).build().perform();
    			}
    		}
    		// The First User Close the Credit Review
    		public void Click_CloseCreditReviewOfUserOne() {
    			if (DriverUtil.isChrome()) {
    				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
        			driver.switchTo().window(tabs2.get(0));
        			Actions tab_close = new Actions(driver);
        			for(int i=0;i<15;i++)
        				tab_close.sendKeys(Keys.TAB).build().perform();
    				tab_close.sendKeys(Keys.ENTER).build().perform();
        			}
    		}
    
}
