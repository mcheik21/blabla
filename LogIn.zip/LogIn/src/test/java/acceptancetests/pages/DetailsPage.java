package acceptancetests.pages;

import acceptancetests.base.DriverUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DetailsPage extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(DetailsPage.class);
    
    public static final String URL="#";
    public DetailsPage(WebDriver driver) {
        super(driver);
    }
    
    @FindBy(how = How.ID, using = "username")
    private WebElement sendTextusernme;
    
    @FindBy(how = How.ID, using = "password")
    private WebElement sendTextpassword;
    
    @FindBy(how = How.ID, using = "loginButton")
    private WebElement clickButton;
    
  
  
    
    public void clickToButton() {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("loginButton")));
        }
        clickButton.click();
    }
    
    public void sendtextUsernsame(String username) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        }
        sendTextusernme.sendKeys(username);
    }
    
    public void sendtextPassword(String password) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        }
        sendTextpassword.sendKeys(password);
    
    
    
      
    
      
    }
}
