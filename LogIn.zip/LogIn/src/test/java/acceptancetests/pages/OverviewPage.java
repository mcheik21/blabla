package acceptancetests.pages;

import acceptancetests.base.DriverUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OverviewPage extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(OverviewPage.class);

    public OverviewPage(WebDriver driver) {
        super(driver);
    }
    @FindBy(how = How.ID, using = "loginButton")
    private WebElement clickAnmelden;
//@AM:find the textfield in the overviewpage
    @FindBy(how = How.ID, using = "username")
    private WebElement usernameTextField;

    @FindBy(how = How.ID, using = "password")
    private WebElement passwordTextField;
    
    @FindBy(how=How.ID,using ="SEC_search_filter-el0-el4")
    private WebElement partnerID;
    
    @FindBy(how=How.ID, using="SEC_search_filter-el0-el1")
    private WebElement SearchID;
    
    @FindBy(how=How.LINK_TEXT, using="50194")
    private WebElement InternalID;
    
    @FindBy(how=How.LINK_TEXT, using ="GoCC")
    private WebElement Gocc;
    @FindBy(how=How.ID, using="new_gocc")
    private WebElement newGocc;
    @FindBy(how=How.ID, using="gocc-aa_others")
    private WebElement detailsGocc;
    @FindBy(how=How.ID, using="gocc_save_button")
    private WebElement saveGocc;
    
   @FindBy(how=How.ID, using="gocc_approve_button")
   private WebElement Finalize;
   @FindBy(how=How.CLASS_NAME, using="errorlevel")
   private WebElement GetDetails;
   
   @FindBy(how=How.XPATH, using="//*[@id='navigation.MENU_client.labelKey']")
   private WebElement selectPartner;
   @FindBy(how=How.LINK_TEXT, using="Search")
   private WebElement SearchPartner;
   
   @FindBy(how=How.ID, using="copy_gocc")
   private WebElement copyGoCC;
   
  
   

   // @FindBy(how = How.ID, using = "duedate")
    //private WebElement duedateTextField;

    //@FindBy(how = How.ID, using = "status")
    //private WebElement statusOptionField;
    
   // @FindBy(how = How.ID, using = "notes")
    //private WebElement notesTextField;
    
//@AM: Method to find the visibilty of the textfield
   
    public boolean checkUsername(String username) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        }
        return usernameTextField.getText().equals(username);
    }
  //@AM: get the variable and send keys
    public void enterUsername(String username) {
        usernameTextField.clear();
        usernameTextField.sendKeys(username);
    }
    
    public boolean checkPassword(String password) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        }
        return passwordTextField.getText().equals(password);
    }
    public void enterPassword(String password) {
       passwordTextField.clear();
        passwordTextField.sendKeys(password);
    }
    
      public void clickAnmeldenButton() {
       if (DriverUtil.isChrome()) {
    	   //WebElement obj1=driver.findElement(By.xpath("//input[@id='loginButton']"));
    	   //obj1.click();
           waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("loginButton")));
       }
       clickAnmelden.click();
    }
    
    
    
    public void multiSelectTest() 
    {
        Select dateDropDown=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
        dateDropDown.selectByIndex(05);        
       
    }
    
    
    public boolean checkID(String marketpartner) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartner")));
        }
        return partnerID.getText().equals(marketpartner);
    }
  //@AM: get the variable and send keys
    public void enterID(String marketpartner) {
    	partnerID.clear();
    	partnerID.sendKeys(marketpartner);
    }
    
    // Click to Search 
    public void clickSearch() {
        if (DriverUtil.isChrome()) {
     	  
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("SEC_search_filter-el0-el1")));
        }
        SearchID.click();
     }
    
    
    // click to the internal number ID
    
    public void clickToInternalID() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("50194")));
    		
    	}
    	InternalID.click();
    }
    
    public void NaviGateToGOCC() {
    	
if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("GoCC")));
    		
    	}
		Gocc.click();
		
		
		    	
    }
    
    // Click the new GOcc button and save it
    
    public void ClcikNew() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("new_gocc")));
    		
    		}
		
    	newGocc.click();
    	
    }
    
    
    // send the details of new GOcc and click on Save
    
    public void ClcikSaveGocc() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc-aa_others")));
    		
    		}
		
    	detailsGocc.sendKeys("Details of New Gocc");
    	waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_save_button")));
    	saveGocc.click();
    	
    	//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("//*[@id='CON_header-el0-el4']/div[3]")));
    	//getGoccID.getText();
    }
    
    // click to finalize
    
    public void ClcikFinalize() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_approve_button")));
    		
    		}
		
    	
    	Finalize.click();
    	
    	
    }
    
    public void DetailsGocc() {
    	if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.className("errorlevel")));
    		
    		//String actualString = GetDetails.getText();

    		//String expectedString = "The Document has been saved successfully with document id";

    		//Assert.assertTrue(actualString.contains(expectedString));
    	
    	}
    	
    }
    public void AssertDocument() {
    	String actualString = GetDetails.getText();

		String expectedString = "The Document has been saved successfully with document id";

		Assert.assertTrue(actualString.contains(expectedString));
	
    	
    }
    
   public void Counterpartner() {
	   
	      
	   waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='navigation.MENU_client.labelKey']")));
	        
	        selectPartner.click();
	      
	    }
     
   // copy Gocc
   public void copyGoCC() {
	   if (DriverUtil.isChrome()) {
   		
   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("copy_gocc")));
   		
   		}
		
   	
	   copyGoCC.click();
	   
	   
   }
   
   
   // New Test CRSP-E2E_BMW
   // select credit borrower
   public void CreditBorrower() 
   {
       Select creditborrower=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
      creditborrower.selectByIndex(01);        
      
   }
   
   
    
    
    
    
    
    
    
    
    
    public void clickUpdateEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnEditEntry = driver.findElement(By.id("edit_"+entryId));
        btnEditEntry.click();
    }
    
    public void clickRemoveEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnRemoveEntry = driver.findElement(By.id("remove_"+entryId));
        btnRemoveEntry.click();
    }
    
    public void clickViewEntryByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement linkViewEntry = driver.findElement(By.id("item_"+entryId));
        linkViewEntry.click();
    }

    public void clickViewEntryBySubject(String subject) {
//        waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));

        String entryId = getEntryIdBySubject(subject);

        clickViewEntryByEntryId(entryId);
    }
    
    /**
     * This method retrieves all Item IDs in the overview page. Since all Table
     * cells like subject etc. contain an element ID with the combination of
     * field_name and entry ID it makes it easy to retrieve further values.
     *
     * @return a List with the contained entry IDs
     */
    public List<String> getAllEntryIds () {
        
        List<String> entryIdList = new ArrayList<>();
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        for (Iterator<WebElement> iterator = itemRows.iterator(); iterator.hasNext();) {
            WebElement webElement = iterator.next();
            //Get the first table cell which contains the item ID
            List<WebElement> findElement = webElement.findElements(By.xpath("td"));
            if( findElement.size() > 0 ){
                entryIdList.add(findElement.get(0).getText());
            }
            
        }
        return entryIdList;
    }
    
    /**
     * This method retrieves the amount of existing entries on the overview page.
     *
     * @ return amount of entries
     * */
    public int getTotalAmountOfEntries () {
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        
        return itemRows.size();
    }
    
    public boolean checkIfEntryWithSubjectExists(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return true;
            }
        }
        
        return false;
    }

    public boolean checkIfEntryWithOwnerExists(String owner) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (owner.equals(findById("owner_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithDueDateExists(String duedate) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (duedate.equals(findById("duedate_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithStatusExists(String status) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (status.equals(findById("status_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }
    
    public String getEntryIdBySubject(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return affectedID;
            }
        }
        
        return null;
    }
    
}
