package acceptancetests.pages;

import acceptancetests.base.DriverUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OverviewPage extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(OverviewPage.class);

    public OverviewPage(WebDriver driver) {
        super(driver);
    }
    @FindBy(how = How.ID, using = "loginButton")
    private WebElement clickAnmelden;
//@AM:find the textfield in the overviewpage
    @FindBy(how = How.ID, using = "username")
    private WebElement usernameTextField;

    @FindBy(how = How.ID, using = "password")
    private WebElement passwordTextField;
    
    @FindBy(how=How.ID,using ="SEC_search_filter-el0-el4") //textbox Counterparty ID
    private WebElement partnerID;
    
    @FindBy(how=How.ID, using="SEC_search_filter-el0-el1") //search button
    private WebElement SearchID;
    
    @FindBy(how=How.LINK_TEXT, using="49087") //pp 49087 i:50194
    private WebElement InternalID;
    
    @FindBy(how=How.LINK_TEXT, using ="GoCC") // GOCC Tab
    private WebElement Gocc;
    
    //@FindBy(how=How.LINK_TEXT, using ="Credit Review") // Credit Review Tab
    //private WebElement CreditReview;
  //*[@id="TABS_client"]/li[3]/a
   @FindBy(how=How.XPATH, using="//*[@id='TABS_client']/li[3]/a")
   private WebElement CreditReview;
    
    @FindBy(how=How.ID, using="new_gocc")
    private WebElement newGocc;
    @FindBy(how=How.ID, using="gocc-aa_others")
    private WebElement detailsGocc;
    @FindBy(how=How.ID, using="gocc_save_button")
    private WebElement saveGocc;
    
   @FindBy(how=How.ID, using="gocc_approve_button")
   private WebElement Finalize;
   @FindBy(how=How.CLASS_NAME, using="errorlevel")
   private WebElement GetDetails;
   
   @FindBy(how=How.XPATH, using="//*[@id='navigation.MENU_client.labelKey']")
   private WebElement selectPartner;
   @FindBy(how=How.LINK_TEXT, using="Search")
   private WebElement SearchPartner;
   
   @FindBy(how=How.ID, using="copy_gocc")
   private WebElement copyGoCC;
   
   @FindBy(how=How.LINK_TEXT, using="50194") //49102;86488; external id:6120039
   private WebElement CreditBorrowerID;
   
  @FindBy(how=How.XPATH, using="//*[@id='TABS_client']/li[2]/a")
  private WebElement FinanzialStatement;
  
  @FindBy(how=How.ID, using="FinancialStatement-el60-el61-el62")
  private WebElement CreateNewFinanzialStatement;
   
  @FindBy(how=How.ID, using="name_button_panel_all-el15-el23")
  private WebElement EndStatementSelection;
  
  @FindBy(how=How.LINK_TEXT, using="Ja")
  private WebElement  ClickJa;
  @FindBy(how=How.LINK_TEXT, using="Yes")
  private WebElement  ClickYes;
  
  @FindBy(how=How.LINK_TEXT, using="Meta Information")
  private WebElement MetaInformation;
  @FindBy(how=How.LINK_TEXT, using="Meta Informationen")
  private WebElement MetaInformationen;
  @FindBy(how=How.XPATH, using="//div[@id='fs_grid_meta_informationGrid_cell_0_unsaved-document']")
  private WebElement SendName;
  
  @FindBy(how=How.ID,using="dropdownlistContentcustomeditorfs_grid_meta_informationGridunsaved-document_2")
  private WebElement DropDownFinancial;
  
  @FindBy(how=How.ID, using="inputcustomeditorfs_grid_meta_informationGridunsaved-document_3")
  private WebElement CalenderStatment;
  @FindBy(how=How.LINK_TEXT,using="Balance Sheet")
  private WebElement BalanceSheet;
  @FindBy(how=How.LINK_TEXT,using="Bilanz")
  private WebElement Bilanz;
  @FindBy(how=How.ID, using="Tab-FinancialStatement-el38-el40-el41Grid_6_unsaved-document_1")
  private WebElement GoodWill;
  @FindBy(how=How.ID, using="Tab-FinancialStatement-el38-el40-el41Grid_143_unsaved-document_1")
  private WebElement ProvisionsBalanceSheet;
  
  @FindBy(how=How.LINK_TEXT, using="Income Statement")
  private WebElement IncomeStatement;
  
  @FindBy(how=How.ID, using="Tab-FinancialStatement-el38-el42-el43Grid_3_unsaved-document_1")
  private WebElement NewVehicles;
  
  @FindBy(how=How.ID, using="Tab-FinancialStatement-el38-el42-el43Grid_69_unsaved-document_1")
  private WebElement InterestAndSimilarExpenses;
  
  @FindBy(how=How.ID, using="Tab-FinancialStatement-el38-el42-el43Grid_138_unsaved-document_1")
  private WebElement DepreciationAndAmotization;
  
 @FindBy(how=How.LINK_TEXT, using="Notes")
 private WebElement Notes;
 
 @FindBy(how=How.CLASS_NAME, using="errorlevel")
 private WebElement GetTextFinancialDocument;
 
 // third scenario
 //Click to Rating
 @FindBy(how=How.XPATH, using="//*[@id=\"TABS_client\"]/li[3]/a")
 private WebElement ClickRating;
 
 // Click New
 @FindBy(how=How.ID, using="Rating-el65-el66-el68-el69")
 private WebElement ClickNewRatingModel;
 
 // Select Statement 
 @FindBy(how=How.XPATH, using="//*[@id=\"TABS\"]/li[1]/a")
 private WebElement  ClickFinancialStatementCreditBorrwer;
 @FindBy(how=How.XPATH, using="//div[@id='TABS-el15-el17-el18']")
 private WebElement SearchTable;
 
 // Click to Select
 @FindBy(how=How.ID, using="TABS-el15-el16")
 private WebElement Click_SelectDifferentStatement;
 
 @FindBy(how=How.LINK_TEXT, using="Material Creditworthiness")
 private WebElement Click_MaterialCreditworthiness;
 
 // send a key
 @FindBy(how=How.ID, using="notching_reason")
 private WebElement send_MaterialCreditworthinees;
 
 // Management & MarketClick_Managementandmarket
 @FindBy(how=How.LINK_TEXT, using="Management & Market")
 private WebElement Click_Managementandmarket;
//@AM: Method to find the visibilty of the textfield
 
 //Business Relation.Click_business_relation
 @FindBy(how=How.LINK_TEXT, using="Business Relation")
 private WebElement Click_business_relation;
 
 //Transfer Risk.Click_transfer_risk
 @FindBy(how=How.LINK_TEXT, using="Transfer Risk")
 private WebElement Click_transfer_risk;
 
 //Support.Click_support
 @FindBy(how=How.LINK_TEXT, using="Support")
 private WebElement Click_support;
 
 // choose no support. no_support.Click_nosupport
@FindBy(how=How.ID, using="no_support")
private WebElement Click_nosupport;

//Override.//*[@id='TABS']/li[7]/a.Click_override
@FindBy(how=How.XPATH, using="//*[@id='TABS']/li[7]/a")
private WebElement Click_override;

   
    public boolean checkUsername(String username) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        }
        return usernameTextField.getText().equals(username);
    }
  //@AM: get the variable and send keys
    public void enterUsername(String username) {
        usernameTextField.clear();
        usernameTextField.sendKeys(username);
    }
    
    public boolean checkPassword(String password) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        }
        return passwordTextField.getText().equals(password);
    }
    public void enterPassword(String password) {
       passwordTextField.clear();
        passwordTextField.sendKeys(password);
    }
    
      public void clickAnmeldenButton() {
       if (DriverUtil.isChrome()) {
    	   //WebElement obj1=driver.findElement(By.xpath("//input[@id='loginButton']"));
    	   //obj1.click();
           waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("loginButton")));
       }
       clickAnmelden.click();
    }
    
      
     
//Dropdown Counterparty type 
    public void multiSelectTest() 
    {
        Select dateDropDown=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
        dateDropDown.selectByIndex(05);        
       
    }
    
    
    public boolean checkID(String marketpartner) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartner")));
        }
        return partnerID.getText().equals(marketpartner);
    }
  //@AM: get the variable Counterparty and send keys
    public void enterID(String marketpartner) {
    	partnerID.clear();
    	partnerID.sendKeys(marketpartner);
    }
    
    // Click to Search 
    public void clickSearch() {
        if (DriverUtil.isChrome()) {
     	  
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("SEC_search_filter-el0-el1")));
        }
        SearchID.click();
     }
    
    
    // click to the internal number ID!!!!
    
    public void clickToInternalID()  {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("49087"))); //pp:49087 i: 50194
    		
    	}
    	InternalID.click();
    	
    	
    }
    
    //GOCC      
    public void NaviGateToGOCC() {
    	
if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("GoCC")));
    		
    	}
		Gocc.click();
		
		
		    	
    }
    //CreditReview   
    public void NaviGateToCreditReview(){
    	
    	
if (DriverUtil.isChrome()) {
    		//driver.findElement(By.linkText("Credit Review")).click();
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='TABS_client']/li[3]/a")));
    		 
}
    	
		CreditReview.click();
				
		    	
    }
    
    // Click the new GOcc button and save it
    
    public void ClcikNew() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("new_gocc")));
    		
    		}
		
    	newGocc.click();
    	
    }
    
    
    // send the details of new GOcc and click on Save
    
    public void ClcikSaveGocc() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc-aa_others")));
    		
    		}
		
    	detailsGocc.sendKeys("Details of New Gocc");
    	waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_save_button")));
    	saveGocc.click();
    	
    	//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("//*[@id='CON_header-el0-el4']/div[3]")));
    	//getGoccID.getText();
    }
    
    // click to finalize
    
    public void ClcikFinalize() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_approve_button")));
    		
    		}
		
    	
    	Finalize.click();
    	
    	
    }
    
    public void DetailsGocc() {
    	if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.className("errorlevel")));
    		
    	
    	
    	}
    	
    }
    public void AssertDocument() {
    	String actualString = GetDetails.getText();

		String expectedString = "The Document has been saved successfully with document id";

		Assert.assertTrue(actualString.contains(expectedString));
	
    	
    }
    
   public void Counterpartner() {
	   
	      
	   waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='navigation.MENU_client.labelKey']")));
	        
	        selectPartner.click();
	      
	    }
     
   // copy Gocc
   public void copyGoCC() {
	   if (DriverUtil.isChrome()) {
   		
   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("copy_gocc")));
   		
   		}
		
   	
	   copyGoCC.click();
	   
	   
   }
   
   
   // New Test CRSP-E2E_BMW
   // select credit borrower
   public void CreditBorrower() 
   {//SEC_search_filter-el0-el11//select2-SEC_search_filter-el0-el11-container
	   Actions creditborrow_tab = new Actions(driver);
	   for(int i=0;i<27;i++)
		   creditborrow_tab.sendKeys(Keys.TAB).build().perform();
			   creditborrow_tab.sendKeys(Keys.ENTER).build().perform();
			   creditborrow_tab.sendKeys(Keys.DOWN).build().perform();
			   creditborrow_tab.sendKeys(Keys.ENTER).build().perform();
      // Select creditborrower=new Select(driver.findElement(By.xpath("//span[@class='select2-SEC_search_filter-el0-el11-container']")));
      //creditborrower.selectByIndex(01);        
      
   }
   
   // select the ID 
   
   public boolean checkCreditBorrowerID(String marketpartnerBorrower) {
       if (DriverUtil.isChrome()) {
           waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartnerBorrower")));
       }
       return partnerID.getText().equals(marketpartnerBorrower);
   }
   
 //@AM: get the variable and send keys
   public void enterCreditBorrowerID(String marketpartnerBorrower) {
   	partnerID.clear();
   	partnerID.sendKeys(marketpartnerBorrower);
   }
   
   
   
   // Select the internal ID of the credit borrower and ISU
   
   public void SelectInternalID() {
   	if (DriverUtil.isChrome()) {
   		
   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("50194")));//49102;86488;49087
   		
   	}
   	CreditBorrowerID.click();
   }
   

   // clcik to Financial Statment
   public void ClickToFinanzialStatment() {
		if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='TABS_client']/li[2]/a")));
	   		
	   	}
	   	FinanzialStatement.click();
	   
   }
   
   // Select the dropDownlis of accounting and the Method
   
   public void SelectAccountingAndMethodFinancial() 
   {
       Select AccountingStandard=new Select(driver.findElement(By.id("client_fs_accounting_standard")));
       AccountingStandard.selectByIndex(01); 
       Select Method=new Select(driver.findElement(By.id("client_fs_method")));
       Method.selectByIndex(02); 
      
   }
   
   // create a new Financial
   public void CreateNewFinancialStatement() {
	   
	   if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("FinancialStatement-el60-el61-el62")));
	   		
	   	}
	   	CreateNewFinanzialStatement.click();
	   
   }
   
   // Click EndStatement and click Yes
   
   public void EndStatementSelectionAndClickYes() {
	   
	   if(DriverUtil.isChrome()) {
			
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("name_button_panel_all-el15-el23")));
	   		
	   	}
	   EndStatementSelection.click();
		   
   }
   
   public void ClickYesToAndStatement() {
	   if(DriverUtil.isChrome()) {
			
	   		//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Ja")));
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Yes")));
	   		
	   	}
	  //ClickJa.click();
	  ClickYes.click();
   }
   
   // MetaInformation
   
   public void ClickMetaInformationAndFillAllInformations() {
	   if(DriverUtil.isChrome()) {
			
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Meta Information")));
	   		
	   		//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Meta Informationen")));
	   	}
	  MetaInformation.click();
	  //MetaInformationen.click();	
   }
   
   //name of  Information Meta
   public void NameOfInformationMeta() {
	   if(DriverUtil.isChrome()) {
			
		   //waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("fs_grid_meta_informationGrid_cell_0_unsaved-document']")));
		   WebDriverWait wait= new WebDriverWait(driver,10);
		   WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='fs_grid_meta_informationGrid_cell_0_unsaved-document']")));
		   element.click();
		   WebElement element1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fs_grid_meta_informationGrid_0_unsaved-document")));
		   element1.sendKeys("Test");
		 //*[@id="row0fs_grid_meta_informationGrid"]/div[2]
		 //*[@id="row0fs_grid_meta_informationGrid"]/div[2]
		  
		   
		  
	   		
	   		
	   	}
	   
   }
   
   public void DropFinancial() {
	   //driver.findElement(By.id ("fs_grid_meta_informationGrid_0_unsaved-document")).click();
	   Actions builder = new Actions(driver);
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();;
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys("03/04/2019");
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys("07/07/2019");
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.TAB).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   builder.sendKeys(Keys.DOWN).build().perform();
	   // Audited statement Click
	   builder.sendKeys(Keys.TAB).build().perform();
	   WebDriverWait wait1= new WebDriverWait(driver,10);
	   WebElement ele = driver.findElement(By.xpath("//div[@id='fs_grid_meta_informationGrid_cell_11_unsaved-document']"));
	   ele.click();
	   Actions action = new Actions(driver);
	   
	   
	   //builder.sendKeys(Keys.TAB).build().perform();
	   
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.TAB).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.TAB).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.TAB).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   action.sendKeys(Keys.DOWN).build().perform();
	   
	   
	    
	   
	   
	    
   }
   //BalanceSheet
   
   public void ClickBalanceSheet() {
	   if(DriverUtil.isChrome()) {
		   
		    waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Balance Sheet")));
	   		//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Bilanz")));
	   		//Bilanz.click();
		    BalanceSheet.click();
	   		Actions actionBalance = new Actions(driver);
	   		actionBalance.sendKeys(Keys.TAB).build().perform();
	   		actionBalance.sendKeys(Keys.TAB).build().perform();
	   		actionBalance.sendKeys(Keys.TAB).build().perform();
	   		actionBalance.sendKeys(Keys.TAB).build().perform();
	   		actionBalance.sendKeys(Keys.TAB).build().perform();
	   		//Tab-FinancialStatement-el38-el40-el41Grid_6_unsaved-document_1
	   		//      //*[@id='row6Tab-FinancialStatement-el38-el40-el41Grid']/div[2]
	   		WebElement ClickGoodWill= driver.findElement(By.xpath("//*[@id='row6Tab-FinancialStatement-el38-el40-el41Grid']/div[2]"));
	   		ClickGoodWill.click();
	   		//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='row6Tab-FinancialStatement-el38-el40-el41Grid']/div[2]")));
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("Tab-FinancialStatement-el38-el40-el41Grid_6_unsaved-document_1")));
	   		GoodWill.sendKeys("10");
	   		// id: Tab-FinancialStatement-el38-el40-el41Grid_143_unsaved-document_1
	   		//xpath: //*[@id='row143Tab-FinancialStatement-el38-el40-el41Grid']/div[2]
	   		
	   		WebElement ClickProvisions = driver.findElement(By.xpath("//*[@id='row143Tab-FinancialStatement-el38-el40-el41Grid']/div[2]"));
	   		ClickProvisions.click();
	   		//ClickProvisions.sendKeys("10"); Tab-FinancialStatement-el38-el40-el41Grid_143_unsaved-document_1
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("Tab-FinancialStatement-el38-el40-el41Grid_143_unsaved-document_1")));
	   		ProvisionsBalanceSheet.sendKeys("10");
	   		
	   	}
	   
	   		
	   		
	   	
   }
   public void IncomeStatment() {
	   	if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Income Statement")));
	   		
	   	}
	   	IncomeStatement.click();
	   	for(int i=0;i<4;i++) {
	   		Actions IncomeStatementTab = new Actions(driver);
	   		IncomeStatementTab.sendKeys(Keys.TAB);
	   		
	   	}
	   	
	  //xpath: //*[@id="row3Tab-FinancialStatement-el38-el42-el43Grid"]/div[2]
			WebElement ClickNewVehicles = driver.findElement(By.xpath("//*[@id=\"row3Tab-FinancialStatement-el38-el42-el43Grid\"]/div[2]"));
			ClickNewVehicles.click();
			//id: Tab-FinancialStatement-el38-el42-el43Grid_3_unsaved-document_1
			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("Tab-FinancialStatement-el38-el42-el43Grid_3_unsaved-document_1")));
			NewVehicles.sendKeys("11");
			
			
			
			
			
			
			
			//Tab-FinancialStatement-el38-el42-el43Grid_62_unsaved-document_1
			//Tab-FinancialStatement-el38-el42-el43Grid_138_unsaved-document_1; DepreciationAndAmotization
			WebElement Depriciation = driver.findElement(By.xpath("//*[@id=\"row49Tab-FinancialStatement-el38-el42-el43Grid\"]/div[2]"));
			Depriciation.click();
			Actions Dep = new Actions(driver);
			Dep.sendKeys("13");
			//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("Tab-FinancialStatement-el38-el42-el43Grid_138_unsaved-document_1")));
			//DepreciationAndAmotization.sendKeys("12");
			
			// p1120 interest & similar expenses  
			for(int j=0;j<24;j++)
			{
				Dep.sendKeys(Keys.TAB).build().perform();
				
			
			}
			Dep.sendKeys("12");
			Dep.sendKeys(Keys.TAB).build().perform();
	   }
   
   // click to Notes
    public void ClickToNote() {
    	
 	if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Notes")));
	   		
	   	}
	   	Notes.click();
	   	
	   	Actions note = new Actions(driver);
	   	note.sendKeys(Keys.TAB);
	   	WebElement Note_click = driver.findElement(By.xpath("//*[@id=\"row0Tab-FinancialStatement-el38-el48-el49Grid\"]/div[2]"));
	   	Note_click.click();
	   	// editAreaId
	   	WebElement Note_Edit = driver.findElement(By.id("editAreaId"));
	   	Note_Edit.sendKeys("The New Financial is created ");
	   	// a href : Ok
	   	WebElement Click_OK= driver.findElement(By.linkText("Ok"));
	   	Click_OK.click();
	   	
	   	// save and calculate
	   	//id -save: name_button_panel_all_bottom-el75-el80
	   	
	   	WebElement Click_Save = driver.findElement(By.id("name_button_panel_all_bottom-el75-el80"));
	   	Click_Save.click();
	   	
	   	// get the text to Assert it: id to the text:  //*[@id="id10c"]/ul/li
	   	/*
	   	 * 
	   	 * */
	   	
	   	
	   	// Click Calculate after assert
	   	//id: name_button_panel_all-el15-el16
	   	WebElement Click_Calculate = driver.findElement(By.id("name_button_panel_all-el15-el16"));
	   	Click_Calculate.click();
	   	
	   	// send for finalization
	   	WebElement Click_Send_Finalization = driver.findElement(By.id("name_button_panel_all-el15-el21"));
	   	
	   	Click_Send_Finalization.click();
	   	
	   	// Click to Finalize
	   	WebElement Click_Finalize= driver.findElement(By.id("name_button_panel_all-el15-el18"));
	   	Click_Finalize.click();
	   	
	   	
    	
   }
    // get the text to financial and Validate 
    
    public void AssertDocumentFinancial() {
    	if(DriverUtil.isChrome()) {
    		//*[@id="id10c"]/ul/li
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.className("errorlevel")));
    		//String Text=GetTextFinancialDocument.getText();
    		//System.out.println("The text assert is." + Text );
    		
    		String Actual_String_Financial=GetTextFinancialDocument.getText() ;
        	String expected_stringFinancial="The Statement has been saved with ID ";
        	Assert.assertTrue(Actual_String_Financial.contains(expected_stringFinancial));
    		
    		
    		
    	}
    }
    
    // third scenario 
    // Click Rating 
    public void ClickRating() {
    	if(DriverUtil.isChrome()) {
    		//*[@id="TABS_client"]/li[3]/a
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"TABS_client\"]/li[3]/a")));
    		
    	}
    	ClickRating.click();
    	
    }
    
    
    // Select RatingModel
    
    
    public void RatingModel() {
    	if(DriverUtil.isChrome()) {
    
        Select dateDropDown=new Select(driver.findElement(By.id("select_rating_model")));
        dateDropDown.selectByIndex(02);        
       
    	}
    }
    
    // Click New
    public void ClickNewRatingModel() {
    	if(DriverUtil.isChrome()) {
    		//*[@id="TABS_client"]/li[3]/a
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("Rating-el65-el66-el68-el69")));
    		
    	}
    	ClickNewRatingModel.click();
    	
    	
    }
    
    // xpath: //*[@id="TABS"]/li[1]/a
    
    public void SelectedFinancialStatement() {
    	if(DriverUtil.isChrome()) {
    		//*[@id="TABS_client"]/li[3]/a    ClickFinancialStatementCreditBorrwer
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"TABS\"]/li[1]/a")));
    		
    	}
    	ClickFinancialStatementCreditBorrwer.click();
    	Actions clicksearch =new Actions(driver);
    	for(int i=0;i<22;i++)
    	{	
    		clicksearch.sendKeys(Keys.TAB).build().perform();
    		
    	}
    	
    	clicksearch.sendKeys(Keys.ENTER).build().perform();
    	waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("TABS-el15-el16")));
    	Click_SelectDifferentStatement.click();//TABS-el15-el16;Click_SelectDifferentStatement
    	
    }
    
    // material Click_MaterialCreditworthiness;
    
    public void Click_MaterialCreditWorthiness() {
    	if(DriverUtil.isChrome()) {
    		//*[@id="TABS_client"]/li[3]/a    ClickFinancialStatementCreditBorrwer
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Material Creditworthiness")));
    		
    		
    	}
    	
    	Click_MaterialCreditworthiness.click();
    	//notching_reason
    	waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("notching_reason")));
    	send_MaterialCreditworthinees.sendKeys("New Material CreditWorthiness");
    	
    }
    public void Click_ManagementAndMarket() {
    	
    	
    	//Management & MarketClick_Managementandmarket
    	
    	if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Management & Market")));
    		
    		
    	}
    	
    	Click_Managementandmarket.click();
    	// rating_management_market_location_teilnote
    	
    	Select rating_management_location=new Select(driver.findElement(By.id("rating_management_market_location_teilnote")));
    	rating_management_location.selectByIndex(02);
    	
    	//rating_management_market_market_share_teilnote
    	Select rating_management_market_share_teilnote=new Select(driver.findElement(By.id("rating_management_market_market_share_teilnote")));
    	rating_management_market_share_teilnote.selectByIndex(03);
    	//rating_management_market_stock_mgmt_teilnote
    	Select rating_management_mgmt_teilnote=new Select(driver.findElement(By.id("rating_management_market_stock_mgmt_teilnote")));
    	rating_management_mgmt_teilnote.selectByIndex(02);
    	//rating_management_market_income_teilnote
    	Select rating_management_market_income_teilnote=new Select(driver.findElement(By.id("rating_management_market_income_teilnote")));
    	rating_management_market_income_teilnote.selectByIndex(03);
    	//rating_management_market_corporate_mgmt_teilnote
    	Select rating_management_market_corporate_teilnote=new Select(driver.findElement(By.id("rating_management_market_corporate_mgmt_teilnote")));
    	rating_management_market_corporate_teilnote.selectByIndex(02);
    	// rating_management_market_cooperation_teilnote
    	Select rating_management_market_cooperation_teilnote=new Select(driver.findElement(By.id("rating_management_market_cooperation_teilnote")));
    	rating_management_market_cooperation_teilnote.selectByIndex(03);
    	//rating_management_market_customs_teilnote
    	Select rating_management_market_customs_teilnote=new Select(driver.findElement(By.id("rating_management_market_customs_teilnote")));
    	rating_management_market_customs_teilnote.selectByIndex(02);
    	//rating_management_market_grey_imports_teilnote
    	Select rating_management_market_grey_imports_teilnote=new Select(driver.findElement(By.id("rating_management_market_grey_imports_teilnote")));
    	rating_management_market_grey_imports_teilnote.selectByIndex(03);
    	//rating_management_market_automotive_industry_teilnote
    	Select rating_management_market_automotive_industry_teilnote=new Select(driver.findElement(By.id("rating_management_market_automotive_industry_teilnote")));
    	rating_management_market_automotive_industry_teilnote.selectByIndex(02);
    	//rating_management_market_structural_growth_teilnote
    	Select rating_management_market_structural_growth_teilnote=new Select(driver.findElement(By.id("rating_management_market_structural_growth_teilnote")));
    	rating_management_market_structural_growth_teilnote.selectByIndex(02);
    	
   
    }
    //Business Relation.Click_business_relation
    public void Click_BusinessRelation() {
    	
if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Business Relation")));
    		
    	}

		Click_business_relation.click();
		
		//rating_business_rel_cooperation_teilnote
		Select rating_business_rel_cooperation_teilnote=new Select(driver.findElement(By.id("rating_business_rel_cooperation_teilnote")));
    	rating_business_rel_cooperation_teilnote.selectByIndex(02);
		//rating_business_rel_payment_history_teilnote
    	Select rating_business_rel_payment_history_teilnote=new Select(driver.findElement(By.id("rating_business_rel_payment_history_teilnote")));
    	rating_business_rel_payment_history_teilnote.selectByIndex(02);
    	
    }
    
    //Transfer Risk.Click_transfer_risk
    public void Click_TransferRisk() {
if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Transfer Risk")));
    		
    	}

		Click_transfer_risk.click();
		// transfer_risk_country
		Select transfer_risk_country = new Select(driver.findElement(By.id("transfer_risk_country")));
    	transfer_risk_country.selectByIndex(15);
		
		
    }
    
    // Support.Click_support
    public void Click_Support(){
if(DriverUtil.isChrome()) {
	
			//WebElement x= driver.findElement(By.linkText("Override"));
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Support")));
    		
    	}

		Click_support.click();
		
		//no_support.Click_nosupport
		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("no_support")));
		Click_nosupport.click();
		//TABSContainer
		//driver.findElement(By.id("TABSContainer")).click();
		
		
    }
    public void Click_Override() {
		

    	//driver.findElement(By.linkText("Override")).click();
    	
    	
    }
    
    
    
    
    
   
   
  
   
   
   
   
   
   

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
    
    
    
    
    
    
    
    
    public void clickUpdateEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnEditEntry = driver.findElement(By.id("edit_"+entryId));
        btnEditEntry.click();
    }
    
    public void clickRemoveEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnRemoveEntry = driver.findElement(By.id("remove_"+entryId));
        btnRemoveEntry.click();
    }
    
    public void clickViewEntryByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement linkViewEntry = driver.findElement(By.id("item_"+entryId));
        linkViewEntry.click();
    }

    public void clickViewEntryBySubject(String subject) {
//        waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));

        String entryId = getEntryIdBySubject(subject);

        clickViewEntryByEntryId(entryId);
    }
    
    /**
     * This method retrieves all Item IDs in the overview page. Since all Table
     * cells like subject etc. contain an element ID with the combination of
     * field_name and entry ID it makes it easy to retrieve further values.
     *
     * @return a List with the contained entry IDs
  */
    public List<String> getAllEntryIds () {
        
        List<String> entryIdList = new ArrayList<>();
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        for (Iterator<WebElement> iterator = itemRows.iterator(); iterator.hasNext();) {
            WebElement webElement = iterator.next();
            //Get the first table cell which contains the item ID
            List<WebElement> findElement = webElement.findElements(By.xpath("td"));
            if( findElement.size() > 0 ){
                entryIdList.add(findElement.get(0).getText());
            }
            
        }
        return entryIdList;
    }
    
    /**
     * This method retrieves the amount of existing entries on the overview page.
     *
     * @ return amount of entries
     */
    public int getTotalAmountOfEntries () {
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        
        return itemRows.size();
    }
    
    public boolean checkIfEntryWithSubjectExists(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return true;
            }
        }
        
        return false;
    }

    public boolean checkIfEntryWithOwnerExists(String owner) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (owner.equals(findById("owner_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithDueDateExists(String duedate) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (duedate.equals(findById("duedate_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithStatusExists(String status) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (status.equals(findById("status_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }
    
    public String getEntryIdBySubject(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return affectedID;
            }
        }
        
        return null;
    }
    


}
