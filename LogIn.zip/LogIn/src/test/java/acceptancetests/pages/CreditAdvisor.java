package acceptancetests.pages;
import acceptancetests.base.DriverUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class CreditAdvisor extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(CreditreviewPage.class);

    public CreditAdvisor(WebDriver driver) {
        super(driver);
    }
    
    //......................................................................................................................//
    //.................................CRSP-E2E_Motorbike,aggregation,no rating unit in the system..........................//
    //.......................................................Credit Advisor.................................................//
}
