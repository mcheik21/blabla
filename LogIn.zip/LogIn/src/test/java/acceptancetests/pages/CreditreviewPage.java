package acceptancetests.pages;


import acceptancetests.base.DriverUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreditreviewPage extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(CreditreviewPage.class);

    public CreditreviewPage(WebDriver driver) {
        super(driver);
    }
    //........................................................................//
    //............................Step30-CRSP-E2E_IF..........................//
    //........................................................................//
    
    
    
   @FindBy(how = How.ID, using ="loginButton")
   private WebElement clickAnmelden;
   //@AM:find the textfield in the GoccPage
   @FindBy(how = How.ID, using = "username")
   private WebElement usernameTextField;
   @FindBy(how = How.ID, using = "password")
   private WebElement passwordTextField;
   @FindBy(how=How.ID,using ="SEC_search_filter-el0-el4") //textbox Counterparty ID
   private WebElement partnerID;
   @FindBy(how=How.ID, using="SEC_search_filter-el0-el1") //search button
   private WebElement SearchID;
   @FindBy(how=How.LINK_TEXT, using="50194") //pp 49087 i:50194
   private WebElement InternalID;
   @FindBy(how=How.LINK_TEXT, using ="GoCC") // GOCC Tab
   private WebElement Gocc;
   @FindBy(how=How.XPATH, using="//*[@id='TABS_client']/li[3]/a")
   private WebElement CreditReview;
   // Select from Secondary check box 
   @FindBy(how=How.XPATH,using="//*[@id='id3c5']")
   private WebElement Select_fromdropdownlistsecondaryISU;
    // Select new Credit Review
   @FindBy(how=How.XPATH, using="//*[@id='new_credit_review']")
   private WebElement  Select_newcreditreview ;
   // Select the General information
   @FindBy(how=How.LINK_TEXT, using="General Information")
   private WebElement Click_generalinformation; 
   // Select the credit Review
   @FindBy(how=How.LINK_TEXT,using="Credit Application")
   private WebElement Click_creditapplication;
   // Select the line overview
   @FindBy(how=How.LINK_TEXT,using="Line Overview")
   private WebElement Click_lineoverview;
   // Select the business Relationship 
   @FindBy(how=How.LINK_TEXT,using="Business Relationship")
   private WebElement Click_businessrelationship;
   // Select the documentation !8 KWG
   @FindBy(how=How.LINK_TEXT,using="Documentation �18 KWG")
   private WebElement Click_documentationkwg;
   // Select the Economic Situation
   @FindBy(how=How.LINK_TEXT,using="Economic Situation")
   private WebElement Click_economicsituation;
   // Select the Debt Service Ability
   @FindBy(how=How.LINK_TEXT,using="Debt Service Ability")
   private WebElement Click_debtserviceability;
   // Select the Collaterals
   @FindBy(how=How.LINK_TEXT,using="Collaterals")
   private WebElement Click_collaterals;
   // Select the Votes
   @FindBy(how=How.LINK_TEXT,using="Votes")
   private WebElement Click_votes; 
   // Select The Approval
   @FindBy(how=How.LINK_TEXT,using="Approval")
   private WebElement Click_approval;
   // Select the Attachment
   @FindBy(how=How.LINK_TEXT,using="Attachments")
   private WebElement Click_attachment;
   // Select Save Button
   @FindBy(how=How.ID, using="credit_review_save_button_bottom")
   private WebElement Click_savebutton;
   // Select the Finalize
   @FindBy(how=How.ID, using="credit_review_approve_button")
   private WebElement Click_finalizebutton;
   // Seelct Print Button
   @FindBy(how=How.ID, using="falseprint_button")
   private WebElement Click_printbutton;
   // Select the copy of level short ISU
   @FindBy(how=How.ID, using="copy_credit_review")
   private WebElement Click_copylevelshortISU;
   //Select Save level short ISU      
   @FindBy(how=How.ID,using="credit_review_save_button_bottom")
   private WebElement Click_savelevelshortISU;
   // Select Finalize
   @FindBy(how=How.ID, using="credit_review_approve_button")
   private WebElement Click_finalizelevelshortISU;
   // Select the print
   @FindBy(how=How.ID, using="falseprint_button")
   private WebElement Click_PrintlevelshortISU;
   
   
   //........................................................................//
   //............................Step30-CRSP-E@E_IF..........................//
   //.................................Finished...............................//
  
   
   
   //........................................................................//
   //............................Step30-CRSP-E@E_IF..........................//
   //.................................Code...................................//
   
   
   
   
   
   		public boolean checkUsername(String username) {
   			if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
   			}
        return usernameTextField.getText().equals(username);
        }
    	//@AM: get the variable and send keys
   		public void enterUsername(String username) {
   			usernameTextField.clear();
   			usernameTextField.sendKeys(username);
   		}
   		// Password
   		public boolean checkPassword(String password) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        }
        	return passwordTextField.getText().equals(password);
   		}
   		// enter the password
   		public void enterPassword(String password) {
   			passwordTextField.clear();
   			passwordTextField.sendKeys(password);
   		}
   		// Click To Login
   		public void clickAnmeldenButton() {
   			if (DriverUtil.isChrome()) {
   				waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("loginButton")));
       }
       clickAnmelden.click();
   	   }
   		//Dropdown Counterparty type 
   		public void multiSelectTest(){
   		      Select dateDropDown=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
   		      dateDropDown.selectByIndex(05);        
       }
   	   // check ID
   		public boolean checkID(String marketpartner) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartner")));
        }
        return partnerID.getText().equals(marketpartner);
    }
  //@AM: get the variable Counterparty and send keys
    public void enterID(String marketpartner) {
    	partnerID.clear();
    	partnerID.sendKeys(marketpartner);
    }
    // Click to Search 
    public void clickSearch() {
        if (DriverUtil.isChrome()) {
     	  
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("SEC_search_filter-el0-el1")));
        }
        SearchID.click();
     }
     // click to the internal number ID!!!!
     public void clickToInternalID()  {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("50194"))); //pp:49087 i: 50194
    	}
    	InternalID.click();
    }
    
    //CreditReview   
    public void NaviGateToCreditReview(){
    	if (DriverUtil.isChrome()) {    		   		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='TABS_client']/li[3]/a")));
    	}
    	CreditReview.click();		    	
    }
    
    // select Items from dropdown list in credit Review
    public void Select_FromDropDownListCreditReview(){
    	    	
    	if (DriverUtil.isChrome()) {// credit_review_drop_down.Select_fromdropdownListcreditreview
    		Select dateDropDown=new Select(driver.findElement(By.id("credit_review_drop_down")));
            dateDropDown.selectByIndex(02); 
    	}		    	
    }
    //Select Primary ISU   
    public void Select_FromDropDownListPrimaryISU() {// credit_review_primary_business_line_drop_down
    	if (DriverUtil.isChrome()) {// credit_review_drop_down.Select_fromdropdownListcreditreview
    		Select dateDropDown=new Select(driver.findElement(By.id("credit_review_primary_business_line_drop_down")));
            dateDropDown.selectByIndex(02); 
    	}	    	
    }
    // Select one Of checkBox
     public void Select_FromDropDownListSecondaryISU() {
    	if (DriverUtil.isChrome()) {
    		Actions Click_SecondaryISU = new Actions(driver);
    		Click_SecondaryISU.sendKeys(Keys.TAB).build().perform();
    		Click_SecondaryISU.sendKeys(Keys.ENTER).build().perform();
    		}    	
    }
     //Select the New Credit Review
     public void Select_NewCreditReview() {
    	 if (DriverUtil.isChrome()) {// id: new_credit_review.new_credit_review
    		 Actions new_clickLong = new Actions(driver);
    		 new_clickLong.sendKeys(Keys.TAB).build().perform();
    		 new_clickLong.sendKeys(Keys.TAB).build().perform();
    		 new_clickLong.sendKeys(Keys.TAB).build().perform();
    		 new_clickLong.sendKeys(Keys.TAB).build().perform();
    	   	//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='new_credit_review']")));
    		 driver.findElement(By.xpath("//*[@id='new_credit_review']")).click();
     		} 
    	 //Select_newcreditreview.click();
     }
     // Click To General Information
     public void Click_GeneralInformation() throws InterruptedException {
    	 if (DriverUtil.isChrome()) {//a href= General Information. Click_generalinformation
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("General Information")));
    		 Click_generalinformation.click();
    		 Actions ResubmissionDate = new Actions(driver);
    		 for(int i=0;i<13;i++)
    			 ResubmissionDate.sendKeys(Keys.TAB).build().perform();
    		 Thread.sleep(1000);
    		 ResubmissionDate.sendKeys("04/16/2019");
    		 Thread.sleep(1000);
    		 ResubmissionDate.sendKeys(Keys.TAB).build().perform();
    		 ResubmissionDate.sendKeys("03/13/2019"); 
    		 	for(int i=0;i<5;i++)
    		 		ResubmissionDate.sendKeys(Keys.TAB).build().perform();
    		 	ResubmissionDate.sendKeys("The new Data ........Yield data");
    		 	ResubmissionDate.sendKeys(Keys.TAB).build().perform();
    		 	ResubmissionDate.sendKeys("Comments to.......... the rating");
    		 	ResubmissionDate.sendKeys(Keys.TAB).build().perform();
    		 	ResubmissionDate.sendKeys("Default ......./......... risk precaution");
    		 
    	 }
     }
     // Click To Credit Application
     public void Click_CreditApplication() throws InterruptedException {
    	 if (DriverUtil.isChrome()) {// a href: Credit Application.Click_creditapplication
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Credit Application")));
    	 } 
    	 Click_creditapplication.click();
    	 // Select the DropDown in Credit application with id: credit_review-credit_application-application_reasonsw1z-reason
    	 Select dateDropDown=new Select(driver.findElement(By.id("credit_review-credit_application-application_reasonsw1z-reason")));
         dateDropDown.selectByIndex(03);
         // Comment in text area with id:credit_review-credit_application-application_reasonsw1z-comment
         WebElement TextArea = driver.findElement(By.id("credit_review-credit_application-application_reasonsw1z-comment"));
         TextArea.sendKeys("The new Comment is... about the credit application reason");
         Actions NewTab = new Actions(driver);
         NewTab.sendKeys(Keys.TAB).build().perform();
         NewTab.sendKeys(Keys.TAB).build().perform();
         NewTab.sendKeys("The new text is created................");
         NewTab.sendKeys(Keys.TAB).build().perform();
         Thread.sleep(1000);
         NewTab.sendKeys("The new text is created................");
         Thread.sleep(1000);
         }
     // Select Line Overview
     public void Click_LineOverview() throws InterruptedException {
    	 if (DriverUtil.isChrome()) {// a href:Line Overview.Click_lineoverview
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Line Overview")));
    	 }
    	 Click_lineoverview.click();
    	 // select the drop down list in Line overview with id: initial_cb_for_portfolio_group
    	 Select dateDropDown=new Select(driver.findElement(By.id("initial_cb_for_portfolio_group")));
         Thread.sleep(1000);
    	 dateDropDown.selectByIndex(01);
         // Select Add Credit Borrower in the Line Overview with id:but_add_portfolio_group
         WebElement add_creditborrower = driver.findElement(By.id("but_add_portfolio_group"));
         add_creditborrower.click();
         // Select the business lines with id: portfolio_group_1_portfolio_type_select
         //xpath: //*[@id="portfolio_group_1_portfolio_type_select"]
         Select Business_lines =new Select(driver.findElement(By.xpath("//*[@id='portfolio_group_1_portfolio_type_select']")));
         Business_lines.selectByIndex(02);
         // Confirm the business lines with id:but_confirm_portfolio_group_1
         WebElement Confirm_businessline = driver.findElement(By.id("but_confirm_portfolio_group_1"));
         Confirm_businessline.click();
         }
     // Select the Busines Relation Ship 
     public void Click_BusinessRelationship() {
    	 if (DriverUtil.isChrome()) {// a href:Business Relationship.Click_businessrelationship
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Business Relationship")));
    	 }
    	 Click_businessrelationship.click();
    	 // Select the dropdown list from business relation ship with id:tab_business_relations_abstract_changes
    	 Select dateDropDown=new Select(driver.findElement(By.id("tab_business_relations_abstract_changes")));
         dateDropDown.selectByIndex(0);
     }
     // Select the Documentation KWG 
     public void Click_DocumentationKWG() {
    	 if (DriverUtil.isChrome()) {// a href:Documentation �18 KWG.Click_documentationkwg
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Documentation �18 KWG")));
    	 }
    	 Click_documentationkwg.click();
    	 // Select the dropdown list from ISU with id:selected_ise_cb_names
    	 Select dateDropDown=new Select(driver.findElement(By.id("selected_ise_cb_names")));
         dateDropDown.selectByIndex(1);
         //id:member_evaluated_documents
         dateDropDown=new Select(driver.findElement(By.id("member_evaluated_documents")));
         dateDropDown.selectByIndex(1);
         // id:credit_review_kwg_18_kwg_erfuellt
         dateDropDown=new Select(driver.findElement(By.id("credit_review_kwg_18_kwg_erfuellt")));
         dateDropDown.selectByIndex(1);
     }
     // Select the Economic Situation 
     public void Click_EconomicSituation() {
    	 if (DriverUtil.isChrome()) {// a href:Economic Situation.Click_economicsituation
    		   Actions Economic =new Actions(driver);
    		   Economic.sendKeys(Keys.TAB).build().perform();
    		   Economic.sendKeys(Keys.TAB).build().perform();
    		   Economic.sendKeys(Keys.TAB).build().perform();
    		   Economic.sendKeys(Keys.TAB).build().perform();
    		
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Economic Situation")));
    	 
    	 }
    	 Click_economicsituation.click();
    	 // id:economic_situation_changes
    	 Select dateDropDown=new Select(driver.findElement(By.id("economic_situation_changes")));
         dateDropDown.selectByIndex(0);
     }
     // Select the Debt Service Ability
     public void Click_DebtServiceAbility() {
    	 if (DriverUtil.isChrome()) {// id:economic_situation_changes    	
         waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Debt Service Ability")));
    	 }
         Click_debtserviceability.click();
    	 // id:sec_evaluation_dsa_kdf_gegeben
         Select dateDropDown=new Select(driver.findElement(By.id("sec_evaluation_dsa_kdf_gegeben")));
         dateDropDown.selectByIndex(0);
        }
     // Select the Collaterals
     public void Click_Collaterals() {
    	 if (DriverUtil.isChrome()) {// a href: Collaterals.Click_collaterals 	
         waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Collaterals")));
    	 }
         Click_collaterals.click();
         //id: member_collaterals
         Select dateDropDown=new Select(driver.findElement(By.id("member_collaterals")));
         dateDropDown.selectByIndex(1);
         // id: TABS_CREDIT_REVIEW-el111-el112-el119-el120
         Actions TextFill = new Actions(driver);
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys("  ......................overview collaterals.................");
         //WebElement TextFill = driver.findElement(By.id("TABS_CREDIT_REVIEW-el111-el112-el119-el120"));
         //TextFill.sendKeys("   ......................overview collaterals.................");
    	}
     // Select the Votes 
     public void Click_Votes() {
    	 if(DriverUtil.isChrome()) { //a href: Votes.Click_votes
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Votes")));
    		 }
    	 Click_votes.click();
    	 Actions TextFill = new Actions(driver);
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.ENTER).build().perform();
         TextFill.sendKeys("                        .................Vote Front office .................10 ");
         TextFill.sendKeys(Keys.TAB).build().perform();
         TextFill.sendKeys(Keys.ENTER).build().perform();
         TextFill.sendKeys("                         ..........................................................Vote back office .............................................................................................................................................................20 ");
     }
     // Select the Approval
     public void Click_Approval() {
    	 if(DriverUtil.isChrome()) { //a href: Approval.Click_approval
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Approval")));
    		 }
    	 Click_approval.click();
    	 //idDropDown: credit_review-approversw1z-approver_type
    	 Select dateDropDown=new Select(driver.findElement(By.id("credit_review-approversw1z-approver_type")));
         dateDropDown.selectByIndex(01);
         //idName:credit_review-approversw1z-name
         WebElement Name_approval = driver.findElement(By.id("credit_review-approversw1z-name"));
         Name_approval.sendKeys(" Ali Mcheik ");
         // id-date:credit_review-approversw1z-date
         WebElement date_approval = driver.findElement(By.id("credit_review-approversw1z-date"));
         date_approval.sendKeys("03/14/2019");        		 
     	}
      	// Select the attachment 
     	public void Click_Attachment() throws InterruptedException {
     		if(DriverUtil.isChrome()) { //a href: Attachments.Click_attachment
    		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Attachments")));
    		 }
    	 Click_attachment.click(); 
    	 // id-attachment: TABS_CREDIT_REVIEW-el166-el167-el168
    	 Actions add_attachment = new Actions(driver);
    	 add_attachment.sendKeys(Keys.TAB).build().perform();
    	 add_attachment.sendKeys(Keys.TAB).build().perform();
    	 //String File_path = "\\\\uh0151002.bmwgroup.net\\home$\\QXY3535\\bmw_testFile.txt";
    	 //WebElement chooseFile = driver.findElement(By.xpath("//input[@type='file']"));
    	 //Thread.sleep(1000);
    	// chooseFile.sendKeys(File_path);
    	// Thread.sleep(2000);
    	 //add_attachment.sendKeys(Keys.TAB).build().perform();
    	 //add_attachment.sendKeys(Keys.ENTER).build().perform();
    	 //Thread.sleep(2000);
    	 /*
    	 driver.findElement(By.xpath("//input[@type='file']")).click();
    	 //driver.findElement(By.id("TABS_CREDIT_REVIEW-el181-el182-el183")).click();
    	 //Thread.sleep(2000);
    	 //Runtime.getRuntime().exec("C:\\Users\\QXY3535\\Desktop\\bmw_testFile.txt");
    	// Thread.sleep(2000);
    	 //add_attachment.sendKeys(Keys.ENTER).build().perform();
    	     	 String File_path = "\\uh0151002.bmwgroup.net\\home$\\QXY3535\bmw_testFile.txt";
    	     	 add_attachment.sendKeys(File_path);
    	     	Thread.sleep(4000);
    	     	add_attachment.sendKeys(Keys.TAB).build().perform();
    	 //add_attachment.sendKeys(File_path);
    	 //add_attachment.sendKeys(Keys.TAB).build().perform();
    	 add_attachment.sendKeys(Keys.ENTER).build().perform();
    	 Thread.sleep(2000);
    	 //add_attachment.sendKeys(Keys.TAB).build().perform();
    	// add_attachment.sendKeys(".............The new File is Upload.............");
    	*/
    	 }
     	// Select Save Button
     	public void Click_SaveButton() {
     		if(DriverUtil.isChrome()) { //id:credit_review_save_button_bottom.Click_savebutton
       		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("credit_review_save_button_bottom")));
       		 }
       	 Click_savebutton.click(); 
     	}	
     	// Select the Finalize
     	public void Click_FinalizeButton() {
     		if(DriverUtil.isChrome()) { //id:credit_review_approve_button.Click_finalizebutton
          		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("credit_review_approve_button")));
          		 }
          	 Click_finalizebutton.click(); 
     	}
     	// Select Print Button
     	public void Click_PrintButton() {
     		if(DriverUtil.isChrome()) { //id:falseprint_button. Click_printbutton
          		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("falseprint_button")));
          		 }
          	 Click_printbutton.click(); 
     	}
     	// Select Logout
     	public void Click_CounterParty() {
     		if(DriverUtil.isChrome()) { 
     			Actions Click_logout = new Actions(driver);
     			for(int i=0;i<41;i++)
     				Click_logout.sendKeys(Keys.TAB).build().perform();
     			Click_logout.sendKeys(Keys.ENTER).build().perform();
         		 }
         }
     	 // Select the Short Level ISU
     	public void Click_LevelShortISU() {
     		if(DriverUtil.isChrome()) { 
     			Select dateDropDown=new Select(driver.findElement(By.id("credit_review_drop_down")));
     	         dateDropDown.selectByIndex(02);
     			// id: credit_review_primary_business_line_drop_down
     	        dateDropDown=new Select(driver.findElement(By.id("credit_review_primary_business_line_drop_down")));
    	         dateDropDown.selectByIndex(02);
    	         }
     	 }
     	// Select copy 
     	public void Click_CopyLevelShortISU() {
     		if(DriverUtil.isChrome()) { //id:copy_credit_review.Click_copylevelshortISU
         		 waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("copy_credit_review")));
         		 }
         	 Click_copylevelshortISU.click(); 
     	}
     	// Select Save LEvel short ISU
     	public void Click_SaveLevelShortISU() {
     		if(DriverUtil.isChrome()) { 
     			Actions click_save = new Actions(driver);
     			click_save.sendKeys(Keys.TAB).build().perform();
     			click_save.sendKeys(Keys.TAB).build().perform();
     			click_save.sendKeys(Keys.ENTER).build().perform();
         		 }
     	}
     	//Select the Finalize
     	public void Click_FinalizeLevelShortISU() {
     		if(DriverUtil.isChrome()) {// id: credit_review_approve_button.Click_finalizelevelshortISU
     			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("credit_review_approve_button")));
     			}
     			Click_finalizelevelshortISU.click();
     	}
     	// Select Print 
     	public void Click_PrintLevelShortISU() {
     		if(DriverUtil.isChrome()) {// id:falseprint_button.Click_PrintlevelshortISU
     			waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("falseprint_button")));
     			}
     			Click_PrintlevelshortISU.click();
     	}
}


			//........................................................................//
			//............................Step30-CRSP-E@E_IF..........................//
			//.............................The END OF CODE............................//