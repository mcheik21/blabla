package acceptancetests.base;

public class TestDataHelper {

    public static int entriesBeforeTest;
    
}
