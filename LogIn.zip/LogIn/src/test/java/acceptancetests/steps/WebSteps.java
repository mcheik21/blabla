package acceptancetests.steps;

import acceptancetests.base.DriverUtil;
import acceptancetests.base.TestDataHelper;
import acceptancetests.pages.DetailsPage;
import acceptancetests.pages.EditPage;
import acceptancetests.pages.OverviewPage;
import cucumber.api.java8.En;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class WebSteps implements En {
	private static final Logger LOG = LoggerFactory.getLogger(WebSteps.class);
	OverviewPage overviewPage;
    //EditPage editPage;
    DetailsPage detailsPage;
    //
    public WebSteps() {
    	

    	 Given("^I navigate to the WEB UI$", () -> {
             WebDriver driver = DriverUtil.getDriver();
             driver.navigate().to(DriverUtil.getTargetWebUrl());
             overviewPage = new OverviewPage(driver);
             TestDataHelper.entriesBeforeTest=overviewPage.getTotalAmountOfEntries();

         });

    	 When("^I enter the value \"([^\"]*)\" into the \"([^\"]*)\" field$", (String value, String field) -> {

             switch(field) {
                 case "username":
                     overviewPage.enterUsername(value);
                     break;
                 case "owner":
                   //  overviewPage.enterOwner(value);
                     break;
                 case "date":
                     // overviewPage.enterDueDate(value);
                     break;
                 case "status":
                     //overviewPage.enterStatus(value);
                     break;
                 case "note":
                     //overviewPage.enterNotes(value);
                     break;
                 default:
                     throw new IllegalArgumentException("Invalid field!");
             }
         });

    	 When("^I click on Add$", () -> {
             // overviewPage.clickAddEntryButton();
          });
          
          When("^I click on Save$", () -> {
             // new EditPage(DriverUtil.getDriver()).clickSaveEntryButton();
          });
          
          When("^I click on Back$", () -> {
             // new EditPage(DriverUtil.getDriver()).clickBackToOverviewButton();
          });

          When("^I click  on \"([^\"]*)\" entry with subject \"([^\"]*)\"$", (String function, String subject) -> {

              switch(function) {
                  case "update":
                      overviewPage.clickUpdateEntryButtonByEntryId(overviewPage.getEntryIdBySubject(subject));
                      break;
                  case "remove":
                      overviewPage.clickRemoveEntryButtonByEntryId(overviewPage.getEntryIdBySubject(subject));
                      break;
                  case "view":
                      LOG.info(subject);
                      overviewPage.clickViewEntryByEntryId(overviewPage.getEntryIdBySubject(subject));
                      break;
                  default:
                      throw new IllegalArgumentException("Invalid function!" + function);
              }

          });

          When("^I click on view entry with entry id \"([^\"]*)\"$", (String entryId) -> {

              overviewPage.clickViewEntryByEntryId(entryId);
          });

          When("^I click on view entry with subject \"([^\"]*)\"$", (String subject) -> {

              overviewPage.clickViewEntryByEntryId(overviewPage.getEntryIdBySubject(subject));
          });

          // 
          Then("^the amount of total web entries was increased by (\\d+)$", (Integer increase) -> {
              Assert.assertEquals(overviewPage.getTotalAmountOfEntries(), TestDataHelper.entriesBeforeTest + increase);
          });
          
          Then("^the amount of total web entries was decreased by (\\d+)$", (Integer decrease) -> {
              Assert.assertEquals(overviewPage.getTotalAmountOfEntries(), TestDataHelper.entriesBeforeTest - decrease);
          });

          Then("^The subject \"([^\"]*)\" does not exist in the overview$", (String subject) -> {
              Assert.assertFalse(overviewPage.checkIfEntryWithSubjectExists(subject));
          });
          
          // 
          Then("^the subject \"([^\"]*)\" exists on the overview page$", (String subject) -> {
              Assert.assertTrue(overviewPage.checkIfEntryWithSubjectExists(subject));
          });

          Then("^the subject \"([^\"]*)\" does not exist in the overview$", (String subject) -> {
              Assert.assertFalse(overviewPage.checkIfEntryWithSubjectExists(subject));
          });

          Then("^the owner \"([^\"]*)\" exists on the overview page$", (String owner) -> {
              Assert.assertTrue(overviewPage.checkIfEntryWithOwnerExists(owner));
          });

          Then("^the owner \"([^\"]*)\" does not exist in the overview$", (String owner) -> {
              Assert.assertFalse(overviewPage.checkIfEntryWithOwnerExists(owner));
          });

          Then("^the due date \"([^\"]*)\" exists on the overview page$", (String dueDate) -> {
              Assert.assertTrue(overviewPage.checkIfEntryWithDueDateExists(dueDate));
          });

          Then("^the due date \"([^\"]*)\" does not exist in the overview$", (String dueDate) -> {
              Assert.assertFalse(overviewPage.checkIfEntryWithDueDateExists(dueDate));
          });

          Then("^the status \"([^\"]*)\" exists on the overview page$", (String status) -> {
              Assert.assertTrue(overviewPage.checkIfEntryWithStatusExists(status));
          });

          Then("^the status \"([^\"]*)\" does not exist in the overview$", (String status) -> {
              Assert.assertFalse(overviewPage.checkIfEntryWithStatusExists(status));
          });

          Then("^the notes \"([^\"]*)\" exists on the overview page$", (String notes) -> {
              //Assert.assertTrue(detailsPage.checkNotes(notes));
          });

          /**
           * DETAIL PAGE
           */

         

           Given("^The subject \"([^\"]*)\" exists in the overview$", (String subject) -> {
              Assert.assertTrue(overviewPage.checkIfEntryWithSubjectExists(subject));
           });

          // -> K-I-S-S: See individual steps definitions
           When("^I enter valid data on the overview page \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$", (String username, String owner, String date, String status, String notes) -> {
              overviewPage.enterUsername(username);
              //overviewPage.enterOwner(owner);
              //overviewPage.enterDueDate(date);
              //overviewPage.enterStatus(status);
              //overviewPage.enterNotes(notes);
           });
        }
    }


