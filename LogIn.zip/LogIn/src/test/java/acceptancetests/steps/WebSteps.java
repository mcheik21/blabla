package acceptancetests.steps;

import acceptancetests.base.DriverUtil;
import acceptancetests.base.TestDataHelper;
//import acceptancetests.pages.DetailsPage;
//import acceptancetests.pages.EditPage;
import acceptancetests.pages.OverviewPage;
import cucumber.api.java8.En;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class WebSteps implements En {
	private static final Logger LOG = LoggerFactory.getLogger(WebSteps.class);
	OverviewPage overviewPage;
    //EditPage editPage;
    //DetailsPage detailsPage;
    //
    public WebSteps() {
    	

    	 Given("^I navigate to the WEB UI$", () -> {
             WebDriver driver = DriverUtil.getDriver();
            driver.navigate().to(DriverUtil.getTargetWebUrl());
             overviewPage = new OverviewPage(driver);
             TestDataHelper.entriesBeforeTest=overviewPage.getTotalAmountOfEntries();

         });

    	 When("^I enter the value \"([^\"]*)\" into the \"([^\"]*)\" field$", (String value, String field) -> {

             switch(field) {
             	 case "username":
             		 overviewPage.enterUsername(value);
                 break;
             
             	 case "password":
             		 overviewPage.enterPassword(value);
                 break;
                                  
                
                 default:
                     throw new IllegalArgumentException("Invalid field!");
             }
         });
    	
    	
    	 And("^I click on Anmelden$", () -> {
    		 Thread.sleep(1000);
              overviewPage.clickAnmeldenButton();
          });
    	 
    	 When("^I Select ISE as the customer Type$", () -> {
    		overviewPage.multiSelectTest();
    		});


When("^I Select \"([^\"]*)\" as the \"([^\"]*)\" Type$", (String customer, String customerdropdown) -> {
    // Write code here that turns the phrase above into concrete actions
	 switch(customerdropdown) {
 	 case "marketpartner":
 		 overviewPage.enterID(customer);
     break;
 	          
    
     default:
         throw new IllegalArgumentException("Invalid field!");
 }
});

  


	When("^I click search button$", () -> {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(10000);
		overviewPage.clickSearch();
    
	});

	When("^Select the Internal ID from the result list$", () -> {
    // Write code here that turns the phrase above into concrete actions
		overviewPage.clickToInternalID() ;
		
		
   
	});

	When("^Navigate to GOCC Tab and Create a New order$", () -> {
		
		overviewPage.NaviGateToGOCC();
   
	});

	When("^Fill in necessary details and Save the order$", () -> {
		
		overviewPage.ClcikNew();
		Thread.sleep(1000);
		overviewPage.ClcikSaveGocc();
		Thread.sleep(1000);
		
		
		
  
	});
    	    	 
    	 When("^I click To Finalize$", () -> {
    		 overviewPage.ClcikFinalize();
    		 Thread.sleep(10000);
    		 overviewPage.DetailsGocc();
    		   
    		});

    		Then("^I verify if a new order is created$", () -> {
    			overviewPage.AssertDocument();
    			
    		   
    		});
    		
    		Then("^verify if the GOCC Template can viewed$", () -> {
    			overviewPage.Counterpartner();
    			overviewPage.multiSelectTest();
    		});
    		

	Then("^I Select again \"([^\"]*)\" as the \"([^\"]*)\"$", (String arg1, String arg2) -> {
		
		 switch(arg2) {
	 	 case "marketpartner":
	 		 overviewPage.enterID(arg1);
	     break;
	 	          
	    
	     default:
	         throw new IllegalArgumentException("Invalid field!");
	 }
		 Thread.sleep(10000);
			overviewPage.clickSearch();
			Thread.sleep(10000);
			overviewPage.clickToInternalID() ;
	    
	});

    		
    			Then("^I verify if GOCC Template can be copied$", () -> {
    			overviewPage.copyGoCC();
    			
    		   
    		});
    			
    			
    			// Second Test CRSP-E2E_IF
    			
    			//login search for credit borrower
    			//select internal id
    			//create new Final.
    			//When("^I Select Credit Borrower as the customer Type$", () -> {
    				//overviewPage.CreditBorrower();
    				
    			    
    			//});

    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
          
    	
    }


}