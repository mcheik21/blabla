package acceptancetests.steps;

import acceptancetests.base.DriverUtil;
import acceptancetests.base.TestDataHelper;
import acceptancetests.pages.CreditreviewPage;
import acceptancetests.pages.GoccPage;
import acceptancetests.pages.CreditReviewLong;
//import acceptancetests.pages.EditPage;
import acceptancetests.pages.OverviewPage;
import cucumber.api.java8.En;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class WebSteps implements En {
	private static final Logger LOG = LoggerFactory.getLogger(WebSteps.class);
	OverviewPage overviewPage;
	GoccPage goccPage;
	CreditreviewPage creditreviewPage;
	CreditReviewLong creditreviewLong;
	public WebSteps() {
    	//......................................................................................//
	 	//.............................Start CRSP_IF(30-50).....................................//
	 	//......................................................................................//
    	
    	// LogIn
    	 Given("^I navigate to the WEB UI$", () -> {
             WebDriver driver = DriverUtil.getDriver();
            driver.navigate().to(DriverUtil.getTargetWebUrl());
            
             overviewPage = new OverviewPage(driver);
             TestDataHelper.entriesBeforeTest=overviewPage.getTotalAmountOfEntries();
             goccPage = new GoccPage(driver);
             TestDataHelper.entriesBeforeTest=goccPage.getTotalAmountOfEntries();
             creditreviewPage = new CreditreviewPage(driver);
             creditreviewLong=new CreditReviewLong(driver);
             //TestDataHelper.entriesBeforeTest=creditreviewPage.getTotalAmountOfEntries();
             // this code of this function in CreditreviewPage
         });
    	 //enter user and password
    	 When("^I enter the value \"([^\"]*)\" into the \"([^\"]*)\" field$", (String value, String field) -> {
    		switch(field) {
             	 case "username":
             		creditreviewPage.enterUsername(value);
             		//goccPage.enterUsername(value);
                 break;             
             	 case "password":
             		creditreviewPage.enterPassword(value);
             		//goccPage.enterPassword(value);             		
                 break;          
                 default:
                     throw new IllegalArgumentException("Invalid field!");
             }
         });
    	// Select Login
    	 And("^I click on Anmelden$", () -> {
    		 Thread.sleep(1000);
    		// goccPage.clickAnmeldenButton();
    		 creditreviewPage.clickAnmeldenButton();
          });
    	 // Select the ISU Type customer
    	 When("^I Select ISU as the customer Type$", () -> {
    		 creditreviewPage.multiSelectTest();
    		 //goccPage.multiSelectTest();
    		});
    	 // enter customer ID
    	 When("^I Select \"([^\"]*)\" as the \"([^\"]*)\" Type$", (String customer, String customerdropdown) -> {
    		 // Write code here that turns the phrase above into concrete actions
    		 switch(customerdropdown) {
    		 	case "marketpartner":
    		 			creditreviewPage.enterID(customer);
    		 			//goccPage.enterID(customer);
    		 			break;
    		 			default:
    		 				throw new IllegalArgumentException("Invalid field!");
    		 	}
    	 	});
    	 // Select Search button
    	 When("^I click search button$", () -> {
    		 // Write code here that turns the phrase above into concrete actions
    		 Thread.sleep(1000);
    		 //overviewPage.clickSearch();
    		 creditreviewPage.clickSearch();
       	 });
    	 // Select Internal ID 
    	 When("^Select the Internal ID from the result list$", () -> {
    		 // Write code here that turns the phrase above into concrete actions
    		 //overviewPage.clickToInternalID() ;
    		 creditreviewPage.clickToInternalID();
		 });
    	 // Credit Review:
    	 When("^I Select the Credit Review$", () -> {
    		 // Write code here that turns the phrase above into concrete actions
			//overviewPage.clickToInternalID() ;
			creditreviewPage.NaviGateToCreditReview();
			});
    	 // SelectFromDropDownListTheCode
    	 When("^I Select the item from DropDownList$", () -> {
    		 // Write code here that turns the phrase above into concrete actions
    		 //overviewPage.clickToInternalID() ;
    		 creditreviewPage.Select_FromDropDownListCreditReview();
    		 creditreviewPage.Select_FromDropDownListPrimaryISU();
    		 creditreviewPage.Select_FromDropDownListSecondaryISU();
    		 creditreviewPage.Select_NewCreditReview();
			});
    	 	//I Click to General Information
    	 	When("^I Click to General Information$", () -> {
    	 		creditreviewPage.Click_GeneralInformation();
			});
    	 	// I Click Credit Application
    	 	When("^I Click Credit Application$", () -> {
    	 		creditreviewPage.Click_CreditApplication();
    	 	});
    	 	// I click Line overview
    	 	When("^I click Line overview$", () -> {
    	 		creditreviewPage.Click_LineOverview();
    	 	});
    	 	// I click to Business Relationship
    	 	When("^I click to Business Relationship$", () -> {
    	 		creditreviewPage.Click_BusinessRelationship();
    	 		Thread.sleep(1000);
    	 	});
    	 	// I click to Documentation KWG
    	 	When("^I click to Documentation KWG$", () -> {
    	 		creditreviewPage.Click_DocumentationKWG();
    	 	});
    	 	// I click To Economic Situation
    	 	When("^I click To Economic Situation$", () -> {
    	 		creditreviewPage.Click_EconomicSituation();
    	 	});
    	 	//I Click to Debt Service Ability
    	 	When("^I Click to Debt Service Ability$", () -> {
    	 		creditreviewPage.Click_DebtServiceAbility();
    	 	});
    	 	//I Click to Collaterals
    	 	When("^I Click to Collaterals$", () -> {
    	 		creditreviewPage.Click_Collaterals();
    	 	});
    	 	//I Click to Votes
    	 	When("^I Click to Votes$", () -> {
    	 		creditreviewPage.Click_Votes();
    	 	});
    	 	//I Click to Approval
    	 	When("^I Click to Approval$", () -> {
    	 		creditreviewPage.Click_Approval();
    	 	});
    	 	//I Click to Attachment
    	 	When("^I Click to Attachment$", () -> {
    	 		creditreviewPage.Click_Attachment();
    	 		
    	 	});
    	 	//I Click to Save
    	 	When("^I Click to Save$", () -> {
    	 		creditreviewPage.Click_SaveButton();
    	 	});
    	 	//I Click to Finalize
    	 	When("^I Click to Finalize$", () -> {
    	 		creditreviewPage.Click_FinalizeButton();
    	 	});
    	 	//I Click to Print
    	 	When("^I Click to Print$", () -> {
    	 		creditreviewPage.Click_PrintButton();
    	 	});
    	 	//I Click LogOut
    	 	When("^I Click LogOut$", () -> {
    	 		creditreviewPage.Click_CounterParty();
    	 	});
    	 	//I Select the level Short ISU
    	 	When("^I Select the level Short ISU$", () -> {
    	 		creditreviewPage.Click_LevelShortISU();
    	 		Thread.sleep(1000);
    	 	});
    	 	//I Click Copy 
    	 	When("^I Click Copy$", () -> {
    	 		Thread.sleep(1000);
    	 		creditreviewPage.Click_CopyLevelShortISU();
    	 		Thread.sleep(2000);
    	 	});
    	 	//I Click Save the level short ISU
    	 	When("^I Click Save the level short ISU$", () -> {
    	 		creditreviewPage.Click_SaveLevelShortISU();
    	 	});
    	 	//I Click Finalize the level short ISU
    	 	When("^I Click Finalize the level short ISU$", () -> {
    	 		creditreviewPage.Click_FinalizeLevelShortISU();
    	 	});
    	 	//I Click Print level short ISU
    		When("^I Click Print level short ISU$", () -> {
    	 		creditreviewPage.Click_PrintLevelShortISU();
    	 	});
    	 	//I Click New credit Review Long
    		When("^I Click New credit Review Long$", () -> {
    	 	//	creditreviewPage.Click_PrintLevelShortISU();
    	 	});
    	 	
    	 	
    	 	
    	 	
    	 	//......................................................//
    	 	//........FinishedStep of CRSP_IF Step(30-50)...........//
    	 	//......................................................//
    		
    		
    		// ......................................................//
    		//....................Credit Review LOng.................//
    		//..........................Start........................//
    		
    		//I Select the Credit Review ISU Level Long
    		When("^I Select the Credit Review ISU Level Long$", () -> {
    	 		creditreviewLong.Click_DropDownLongLevel();
    	 	});
    		//I Select the item of the credit Review Long from DropDownList
    		When("^I Select the item of the credit Review Long from DropDownList$", () -> {
    			 creditreviewLong.Click_ItemPrimaryISU();
    			 Thread.sleep(2000);
    			 creditreviewPage.Select_NewCreditReview();
    			 Thread.sleep(2000);
    	 	});
    		//I click to Documentation Without having III Result §18 KWG filled KWG
    		When("^I click to Documentation Without having III Result KWG filled KWG$", () -> {
   			 creditreviewLong.Click_DocumenationWithoutGermanBanking(); 
   	 	    });
    		//I Click to Confirm
    		When("^I Click to Confirm$", () -> {
    	 		creditreviewLong.Click_ConfirmDocumentationLong();
    	 	});
    		//I Click to Documentation with choose Not Fulfilled and yet not terminated
    		//I click to Documentation Without having III) Result §18 KWG filled KWG
    		When("^I Click to Documentation with choose Not Fulfilled and yet not terminated$", () -> {
   			 creditreviewLong.Click_DocumenationFullfilledGermanBanking(); 
   	 	    });
    		//I Click to Documenation with choose yes
    		When("^I Click to Documenation with choose yes$", () -> {
    			creditreviewPage.Click_DocumentationKWG(); 
      	 	});
    		//I Click to Other Comments
    		When("^I Click to Other Comments$", () -> {
    			creditreviewLong.Click_OtherCommentsLong(); 
      	 	});
    		//I Click LogOut and close the application
    		When("^I Click LogOut and close the application$", () -> {
    			creditreviewLong.Click_LogOutAndCloseApplication(); 
      	 	});
    		//I Click the ID to Finalize it
    		When("^I Click the ID to Finalize it$", () -> {
    			creditreviewLong.Click_InternalIDTOFinalize(); 
      	 	});
    		//I Click to Finalize for ISU level long
    		When("^I Click to Finalize for ISU level long$", () -> {
    			creditreviewLong.Click_FinalizeISULong(); 
      	 	});
    		//I Go Back To ISE on the Marketpartner 
    		When("^I Go Back To ISE on the Marketpartner$", () -> {
    			creditreviewLong.Click_GoBack(); 
      	 	});
    		//I Click Print level long ISU
    		When("^I Click Print level long ISU$", () -> {
    			creditreviewLong.Click_PrintLongTerm(); 
    			
      	 	});
    		//.....................................................................................................................................................................//
    		//.....................................................................................................................................................................//
    		//......................................Test Notification 2 Rating for the User if another User is in the same document................................................//
    		
    		//I save the Rating model
    		When("^I save the Rating model$", () -> {
    			
    			creditreviewLong.Click_SaveRatingModel(); 
      	 	});
    		
    		
    		//Switch Handle To User2
    		When("^Switch Handle To new User$", () -> {
    			
    			creditreviewLong.Click_ClickAndNewTab(); 
      	 	});
    		// Enter the new user and new password
    		When("^I enter the value of new user \"([^\"]*)\" into the \"([^\"]*)\" field$", (String value, String field) -> {
    			switch(field) {
           	 case "username2":
           		creditreviewLong.enterUsername2(value);
           		//goccPage.enterUsername(value);
               break;             
           	 case "password2":
           		creditreviewLong.enterPassword2(value);
           		//goccPage.enterPassword(value);             		
               break;          
               default:
                   throw new IllegalArgumentException("Invalid field!");
    			}
    		});
    		//I open the same Rating
    		When("^I open the same Rating$", () -> {
    			
    			creditreviewLong.Click_OpenSameRating(); 
      	 	});
    		//The first user is close  the specific rating template
    		When("^The first user is close  the specific rating template$", () -> {
    			
    			creditreviewLong.Click_CloseUser1RatingTemplate(); 
    			Thread.sleep(10000);
      	 	});
    		//six minutes later the Second User reopens The same Rating
    		When("^six minutes later the Second User reopens The same Rating$", () -> {
    			Thread.sleep(10000);
    			creditreviewLong.Click_User2ClickSameRating(); 
    			Thread.sleep(10000);
      	 	});
    		//Refresh The page of the second user
    		When("^Refresh The page of the second user$", () -> {
    			Thread.sleep(10000);
    			//creditreviewLong.time();
    			creditreviewLong.Click_User2ClickRefresh(); 
      	 	});
    		//the First user open the same Rating
    		When("^the First user open the same Rating$", () -> {
    			//Thread.sleep(10000);
    			//creditreviewLong.time();
    			creditreviewLong.Click_User1Clicksamerating(); 
      	 	});
    		
    		
    		
    		//................................................................................................................................................//
    		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    		//......................Test 3  Credit Review Notification for the User if another User is in the same document....................................//
    		
    		// I Select ISU as the customer Type of New Credit Review Notification
    		When("^I Select ISU as the customer Type of New Credit Review Notification$", () -> {
    			creditreviewLong.Click_NewISUOfCreditReviewNotification(); 
      	 	});
    		
    		//I Select the Credit Review Notification for the User
    		When("^I Select the Credit Review Notification for the User$", () -> {
    			creditreviewLong.Click_CreditReviewNotification(); 
      	 	});
    		//I Select the item of Credit Review Notification
    		When("^I Select the item of Credit Review Notification$", () -> {
    			creditreviewLong.Click_ItemOfCreditReviewNotification(); 
      	 	});
    		//I Select the item of primary segement business Credit Review
    		When("^I Select the item of primary segement business Credit Review$", () -> {
    			creditreviewLong.Click_CreditReviewNotification(); 
    			creditreviewLong.Click_ItemOfPrimaryCreditReviewNotification(); 
      	 	});
    		//I Click to New Credit Review Notification
    		When("^I Click to New Credit Review Notification$", () -> {
    			creditreviewLong.Click_CreditReviewNotification(); 
    			creditreviewLong.Click_NewCreditReviewNotification(); 
    			Thread.sleep(2000);
      	 	});
    		//the User one save The Credit Review 
    		When("^the User one save The Credit Review$", () -> {
    			creditreviewLong.Click_SaveNewCreditReviewNotification(); 
    		});
    		//I open a new Tab in Chrome or firefox
    		When("^I open a new Tab in Chrome or firefox$", () -> {
    			creditreviewLong.Click_NewTabWindow(); 
    		});
    		//I Select the Same Credit Review of user one
    		When("^I Select the Same Credit Review of user one$", () -> {
    			creditreviewLong.Click_SelectSameRatingModelOfUserOne(); 
    		});
    		//The First User Close the Credit Review
    		When("^The First User Close the Credit Review$", () -> {
    			creditreviewLong.Click_CloseCreditReviewOfUserOne(); 
    		});
    		
    		
    		
    		
    		
    		
	//GOCC
		When("^Navigate to GOCC Tab and Create a New order$", () -> {
			
			//overviewPage.NaviGateToGOCC();
			//creditreviewPage.NaviGateToGOCC();
		});
		

		When("^Fill in necessary details and Save the order$", () -> {
			
			//overviewPage.ClcikNew();
			//Thread.sleep(1000);
			//overviewPage.ClcikSaveGocc();
			//Thread.sleep(1000);
			
			
			
	  
		});
	    	    	 
	    	 When("^I click To Finalize$", () -> {
	    		 //overviewPage.ClcikFinalize();
	    		 //Thread.sleep(10000);
	    		// overviewPage.DetailsGocc();
	    		   
	    		});

	    		Then("^I verify if a new order is created$", () -> {
	    			//overviewPage.AssertDocument();
	    			
	    		   
	    		});
	    		
	    		Then("^verify if the GOCC Template can viewed$", () -> {
	    			//overviewPage.Counterpartner();
	    			//overviewPage.multiSelectTest();
	    		});
	    		

		Then("^I Select again \"([^\"]*)\" as the \"([^\"]*)\"$", (String arg1, String arg2) -> {
			
			 switch(arg2) {
		 	 case "marketpartner":
		 		 overviewPage.enterID(arg1);
		     break;
		 	          
		    
		     default:
		         throw new IllegalArgumentException("Invalid field!");
		 }
			 Thread.sleep(10000);
				overviewPage.clickSearch();
				Thread.sleep(10000);
				overviewPage.clickToInternalID() ;
		    
		});

	    		
	    			Then("^I verify if GOCC Template can be copied$", () -> {
	    			overviewPage.copyGoCC();
	    			
	    		   
	    		});
	    			
	    		
	    			// Second Test CRSP-E2E_IF
	    			
	    			//login search for credit borrower
	    			//select internal id
	    			//create new Final.
	    			
	    			When("^I Select CreditBorrower as the customer Type$", () -> {
	    				overviewPage.CreditBorrower();
	    			});
	    			
	    			

	When("^I Select a \"([^\"]*)\" as the \"([^\"]*)\" Type$", (String customer, String customerdropdown) -> {
	    // Write code here that turns the phrase above into concrete actions
		 switch(customerdropdown) {
	 	 case "marketpartnerBorrower":
	 		 overviewPage.enterCreditBorrowerID(customer);
	     break;
	 	          
	    
	     default:
	         throw new IllegalArgumentException("Invalid field!");
	 }
	});

	// click Search----------the code at the first Scenario

	// Select the internal ID
	When("^Select the InternalID from the result list$", () -> {
	    // Write code here that turns the phrase above into concrete actions
			overviewPage.SelectInternalID() ;
			
			
	   
		});



	// navigate to Finanzial Statment Tab and create a new order
	When("^Navigate to Financial Statement tab and create a new order$", () -> {
	    // Write code here that turns the phrase above into concrete actions
			overviewPage.ClickToFinanzialStatment() ;
			
			
	   
		});

	// Select the Accounting financial and the method
	When("^I Select the Accounting Standard and the Method$", () -> {
	   


	    // Write code here that turns the phrase above into concrete actions
			overviewPage.SelectAccountingAndMethodFinancial() ;
			
			
	   
		});



	// Create a New Financial Statement
	When("^I click to Create New Financial Statement$", () -> {
	    // Write code here that turns the phrase above into concrete actions
			overviewPage.CreateNewFinancialStatement() ;
			
			
	   
		});

	// Click End Statement 
	When("^I click to End Statement selection and click yes$", () -> {
	    // Write code here that turns the phrase above into concrete actions
			overviewPage.EndStatementSelectionAndClickYes() ;
			Thread.sleep(1000);
			
			overviewPage.ClickYesToAndStatement();
			   
		});

	// Meta Information and fill the informations



	When("^I click to Meta Information and Fill all the information$", () -> {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
			overviewPage.ClickMetaInformationAndFillAllInformations() ;
		
			
		
			   
		});


	When("^Fill The Information$", () -> {
	overviewPage.NameOfInformationMeta();
	overviewPage.DropFinancial();
	Thread.sleep(1000);
	overviewPage.ClickBalanceSheet();
	Thread.sleep(1000);
	overviewPage.IncomeStatment();
	Thread.sleep(1000);
	overviewPage.ClickToNote();
	overviewPage.AssertDocumentFinancial();

			

			   
		});


	// 3 Scenario
	// Click To Rating

	When("^I Click Rating$", () -> {
		overviewPage.ClickRating();
	   
	});


	// Choose Rating Model and click new 
	When("^I Choose Rating Model$", () -> {
		overviewPage.RatingModel();
		overviewPage.ClickNewRatingModel();
	   
	});

	When("^Select the Finalized Statements of the Credit Borrower$", () -> {
		Thread.sleep(1000);
		overviewPage.SelectedFinancialStatement();
		
		//overviewPage.Click_SelectCreditBorrower();
		//Thread.sleep(1000);
	});

	// Material Creditworthiness


	When("^Select Material Creditworthiness and up-Downgrade reason$", () -> {
		overviewPage.Click_MaterialCreditWorthiness();
		overviewPage.Click_ManagementAndMarket();
	  
	});
	//The analyst is able to properly document the calculation of the business

	When("^The analyst is able to properly document the calculation of the business$", () -> {
		overviewPage.Click_BusinessRelation();
		
	  
	});

	//Select the country
	When("^I Select the country$", () -> {
		overviewPage.Click_TransferRisk();
		Thread.sleep(1000);
		  
	});

	//I Select the support and choose no support 
	When("^I Select the support and choose no support$", () -> {
		overviewPage.Click_Support();
		  
	});
	//
	When("^I select Override$", () -> {
		//overviewPage.Click_Override();
		
	});
	
	
    }
}