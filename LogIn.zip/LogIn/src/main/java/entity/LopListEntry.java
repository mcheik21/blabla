package entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 *
 * @author qxy3535
 */
public class LopListEntry {
    
    public enum Status {
        PENDING,
        ACTIVE,
        INACTIVE,
        DONE;
        
        public static List<Status> getValues() {
            return Status.getValues();
        }
    }
    
    private String itemId;
    private String username;
    private Date dueDate;
    private String notes;
    private Status status;
    private String password;
    


    public LopListEntry() {
        // needed for JPA!!!!!
    }
    
    public LopListEntry(String username, String password) {
        setUsername(username);
        setPassword(password);
       
    }
    
    
    
  
    

    
    /**
     * @return the Username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }



    


    

   

  
    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param owner the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

   

  

     
    public String getEntryAsJson() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        
        
        String jsonData ="{\",\"username\":\""+this.getUsername()+"\",\"password\":\""+this.getPassword()+"\"}";
        return jsonData;
    }
    
}
