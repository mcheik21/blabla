package acceptancetests.pages;

import acceptancetests.base.DriverUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OverviewPage extends BasePage{
    
    private static final Logger LOG = LoggerFactory.getLogger(OverviewPage.class);

    public OverviewPage(WebDriver driver) {
        super(driver);
    }
    @FindBy(how = How.ID, using = "loginButton")
    private WebElement clickAnmelden;
//@AM:find the textfield in the overviewpage
    @FindBy(how = How.ID, using = "username")
    private WebElement usernameTextField;

    @FindBy(how = How.ID, using = "password")
    private WebElement passwordTextField;
    
    @FindBy(how=How.ID,using ="SEC_search_filter-el0-el4")
    private WebElement partnerID;
    
    @FindBy(how=How.ID, using="SEC_search_filter-el0-el1")
    private WebElement SearchID;
    
    @FindBy(how=How.LINK_TEXT, using="50194")
    private WebElement InternalID;
    
    @FindBy(how=How.LINK_TEXT, using ="GoCC")
    private WebElement Gocc;
    @FindBy(how=How.ID, using="new_gocc")
    private WebElement newGocc;
    @FindBy(how=How.ID, using="gocc-aa_others")
    private WebElement detailsGocc;
    @FindBy(how=How.ID, using="gocc_save_button")
    private WebElement saveGocc;
    
   @FindBy(how=How.ID, using="gocc_approve_button")
   private WebElement Finalize;
   @FindBy(how=How.CLASS_NAME, using="errorlevel")
   private WebElement GetDetails;
   
   @FindBy(how=How.XPATH, using="//*[@id='navigation.MENU_client.labelKey']")
   private WebElement selectPartner;
   @FindBy(how=How.LINK_TEXT, using="Search")
   private WebElement SearchPartner;
   
   @FindBy(how=How.ID, using="copy_gocc")
   private WebElement copyGoCC;
   
   @FindBy(how=How.LINK_TEXT, using="86488")
   private WebElement CreditBorrowerID;
   
  @FindBy(how=How.XPATH, using="//*[@id='TABS_client']/li[2]/a")
  private WebElement FinanzialStatement;
  
  @FindBy(how=How.ID, using="FinancialStatement-el60-el61-el62")
  private WebElement CreateNewFinanzialStatement;
   
  @FindBy(how=How.ID, using="name_button_panel_all-el15-el23")
  private WebElement EndStatementSelection;
  
  @FindBy(how=How.LINK_TEXT, using="Yes")
  private WebElement  ClickYes;
  
  @FindBy(how=How.LINK_TEXT, using="Meta Information")
  private WebElement MetaInformation;
  @FindBy(how=How.XPATH, using="//div[@id='fs_grid_meta_informationGrid_cell_0_unsaved-document']")
  private WebElement SendName;
  
  @FindBy(how=How.ID,using="dropdownlistContentcustomeditorfs_grid_meta_informationGridunsaved-document_2")
  private WebElement DropDownFinancial;

   // @FindBy(how = How.ID, using = "duedate")
    //private WebElement duedateTextField;

    //@FindBy(how = How.ID, using = "status")
    //private WebElement statusOptionField;
    
   // @FindBy(how = How.ID, using = "notes")
    //private WebElement notesTextField;
    
//@AM: Method to find the visibilty of the textfield
   
    public boolean checkUsername(String username) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        }
        return usernameTextField.getText().equals(username);
    }
  //@AM: get the variable and send keys
    public void enterUsername(String username) {
        usernameTextField.clear();
        usernameTextField.sendKeys(username);
    }
    
    public boolean checkPassword(String password) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        }
        return passwordTextField.getText().equals(password);
    }
    public void enterPassword(String password) {
       passwordTextField.clear();
        passwordTextField.sendKeys(password);
    }
    
      public void clickAnmeldenButton() {
       if (DriverUtil.isChrome()) {
    	   //WebElement obj1=driver.findElement(By.xpath("//input[@id='loginButton']"));
    	   //obj1.click();
           waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("loginButton")));
       }
       clickAnmelden.click();
    }
    
    
    
    public void multiSelectTest() 
    {
        Select dateDropDown=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
        dateDropDown.selectByIndex(05);        
       
    }
    
    
    public boolean checkID(String marketpartner) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartner")));
        }
        return partnerID.getText().equals(marketpartner);
    }
  //@AM: get the variable and send keys
    public void enterID(String marketpartner) {
    	partnerID.clear();
    	partnerID.sendKeys(marketpartner);
    }
    
    // Click to Search 
    public void clickSearch() {
        if (DriverUtil.isChrome()) {
     	  
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("SEC_search_filter-el0-el1")));
        }
        SearchID.click();
     }
    
    
    // click to the internal number ID
    
    public void clickToInternalID() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("50194")));
    		
    	}
    	InternalID.click();
    }
    
    public void NaviGateToGOCC() {
    	
if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("GoCC")));
    		
    	}
		Gocc.click();
		
		
		    	
    }
    
    // Click the new GOcc button and save it
    
    public void ClcikNew() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("new_gocc")));
    		
    		}
		
    	newGocc.click();
    	
    }
    
    
    // send the details of new GOcc and click on Save
    
    public void ClcikSaveGocc() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc-aa_others")));
    		
    		}
		
    	detailsGocc.sendKeys("Details of New Gocc");
    	waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_save_button")));
    	saveGocc.click();
    	
    	//waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("//*[@id='CON_header-el0-el4']/div[3]")));
    	//getGoccID.getText();
    }
    
    // click to finalize
    
    public void ClcikFinalize() {
    	if (DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("gocc_approve_button")));
    		
    		}
		
    	
    	Finalize.click();
    	
    	
    }
    
    public void DetailsGocc() {
    	if(DriverUtil.isChrome()) {
    		
    		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.className("errorlevel")));
    		
    		//String actualString = GetDetails.getText();

    		//String expectedString = "The Document has been saved successfully with document id";

    		//Assert.assertTrue(actualString.contains(expectedString));
    	
    	}
    	
    }
    public void AssertDocument() {
    	String actualString = GetDetails.getText();

		String expectedString = "The Document has been saved successfully with document id";

		Assert.assertTrue(actualString.contains(expectedString));
	
    	
    }
    
   public void Counterpartner() {
	   
	      
	   waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='navigation.MENU_client.labelKey']")));
	        
	        selectPartner.click();
	      
	    }
     
   // copy Gocc
   public void copyGoCC() {
	   if (DriverUtil.isChrome()) {
   		
   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("copy_gocc")));
   		
   		}
		
   	
	   copyGoCC.click();
	   
	   
   }
   
   
   // New Test CRSP-E2E_BMW
   // select credit borrower
   public void CreditBorrower() 
   {
       Select creditborrower=new Select(driver.findElement(By.id("SEC_search_filter-el0-el11")));
      creditborrower.selectByIndex(01);        
      
   }
   
   // select the ID 
   
   public boolean checkCreditBorrowerID(String marketpartnerBorrower) {
       if (DriverUtil.isChrome()) {
           waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("marketpartnerBorrower")));
       }
       return partnerID.getText().equals(marketpartnerBorrower);
   }
   
 //@AM: get the variable and send keys
   public void enterCreditBorrowerID(String marketpartnerBorrower) {
   	partnerID.clear();
   	partnerID.sendKeys(marketpartnerBorrower);
   }
   
   
   
   // Select the internal ID of the credit borrower
   
   public void SelectInternalID() {
   	if (DriverUtil.isChrome()) {
   		
   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("86488")));
   		
   	}
   	CreditBorrowerID.click();
   }
   // clcik to Financial Statment
   public void ClickToFinanzialStatment() {
		if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='TABS_client']/li[2]/a")));
	   		
	   	}
	   	FinanzialStatement.click();
	   
   }
   
   // Select the dropDownlis of accounting and the Method
   
   public void SelectAccountingAndMethodFinancial() 
   {
       Select AccountingStandard=new Select(driver.findElement(By.id("client_fs_accounting_standard")));
       AccountingStandard.selectByIndex(01); 
       Select Method=new Select(driver.findElement(By.id("client_fs_method")));
       Method.selectByIndex(02); 
      
   }
   
   // create a new Financial
   public void CreateNewFinancialStatement() {
	   
	   if (DriverUtil.isChrome()) {
	   		
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("FinancialStatement-el60-el61-el62")));
	   		
	   	}
	   	CreateNewFinanzialStatement.click();
	   
   }
   
   // Click EndStatement and click Yes
   
   public void EndStatementSelectionAndClickYes() {
	   
	   if(DriverUtil.isChrome()) {
			
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("name_button_panel_all-el15-el23")));
	   		
	   	}
	   EndStatementSelection.click();
		   
   }
   
   public void ClickYesToAndStatement() {
	   if(DriverUtil.isChrome()) {
			
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Yes")));
	   		
	   	}
	  ClickYes.click();
	   
   }
   
   // MetaInformation
   
   public void ClickMetaInformationAndFillAllInformations() {
	   if(DriverUtil.isChrome()) {
			
	   		waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.linkText("Meta Information")));
	   		
	   		
	   	}
	  MetaInformation.click();
	
   }
   
   //name of  Information Meta
   public void NameOfInformationMeta() {
	   if(DriverUtil.isChrome()) {
			
		   //waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("fs_grid_meta_informationGrid_cell_0_unsaved-document']")));
		   WebDriverWait wait= new WebDriverWait(driver,10);
		   WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='fs_grid_meta_informationGrid_cell_0_unsaved-document']")));
		   element.click();
		   WebElement element1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fs_grid_meta_informationGrid_0_unsaved-document")));
		   element1.sendKeys("Test");
		  
	   		
	   		
	   	}
	   
   }
   
   public void DropFinancial() {
	 //Select element =new Select(driver.findElement(By.id("fs_grid_meta_informationGrid_cell_2_unsaved-document")));
	  //Actions action=new Actions(driver);
	  //action.sendKeys(Keys.TAB).build().perform();
	  
	  //Actions class object
	  Actions builder = new Actions(driver);
	  WebElement mouseElement=driver.findElement(By.id("fs_grid_meta_informationGrid_cell_2_unsaved-document"));
	  //Mouse the cursor focus to mouse element
	  builder.moveToElement(mouseElement).click().build().perform();
	  
	  //Mouse over on the bookcases menu
	  mouseElement = driver.findElement(By.id("fs_grid_meta_informationGrid_cell_2_unsaved-document"));
	  //Mouse the cursor focus to mouse element 
	  builder.moveToElement(mouseElement).click().build().perform();
	  
	  
	  
	  
	 
	  
	
	   
	   
	   
	   
	   
	    
   }
   
   public void enterStatementDate() {
	   Select dateDropDownStatementDate=new Select(driver.findElement(By.xpath("//*[@id='fs_grid_meta_informationGrid_cell_2_unsaved-document']")));
       dateDropDownStatementDate.selectByIndex(02);  
   }
   
   
   
   
  
   
   
   
   
   
   

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
    
    
    
    
    
    
    
    
    public void clickUpdateEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnEditEntry = driver.findElement(By.id("edit_"+entryId));
        btnEditEntry.click();
    }
    
    public void clickRemoveEntryButtonByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement btnRemoveEntry = driver.findElement(By.id("remove_"+entryId));
        btnRemoveEntry.click();
    }
    
    public void clickViewEntryByEntryId(String entryId) {
        if (DriverUtil.isChrome()) {
            waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));
        }
        WebElement linkViewEntry = driver.findElement(By.id("item_"+entryId));
        linkViewEntry.click();
    }

    public void clickViewEntryBySubject(String subject) {
//        waitForElementById(ExpectedConditions.visibilityOfElementLocated(By.id("edit_"+entryId)));

        String entryId = getEntryIdBySubject(subject);

        clickViewEntryByEntryId(entryId);
    }
    
    /**
     * This method retrieves all Item IDs in the overview page. Since all Table
     * cells like subject etc. contain an element ID with the combination of
     * field_name and entry ID it makes it easy to retrieve further values.
     *
     * @return a List with the contained entry IDs
  */
    public List<String> getAllEntryIds () {
        
        List<String> entryIdList = new ArrayList<>();
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        for (Iterator<WebElement> iterator = itemRows.iterator(); iterator.hasNext();) {
            WebElement webElement = iterator.next();
            //Get the first table cell which contains the item ID
            List<WebElement> findElement = webElement.findElements(By.xpath("td"));
            if( findElement.size() > 0 ){
                entryIdList.add(findElement.get(0).getText());
            }
            
        }
        return entryIdList;
    }
    
    /**
     * This method retrieves the amount of existing entries on the overview page.
     *
     * @ return amount of entries
     */
    public int getTotalAmountOfEntries () {
        waitForJSandJQueryToLoad();
        
        List<WebElement> itemRows = driver.findElements(By.className("itemRow"));
        
        return itemRows.size();
    }
    
    public boolean checkIfEntryWithSubjectExists(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return true;
            }
        }
        
        return false;
    }

    public boolean checkIfEntryWithOwnerExists(String owner) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (owner.equals(findById("owner_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithDueDateExists(String duedate) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (duedate.equals(findById("duedate_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }

    public boolean checkIfEntryWithStatusExists(String status) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();

        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (status.equals(findById("status_"+affectedID).getText())) {
                return true;
            }
        }

        return false;
    }
    
    public String getEntryIdBySubject(String subject) {
        waitForJSandJQueryToLoad();
        List<String> containedIDs = getAllEntryIds();
        
        //iterate over the subjects in order to find the right one
        for (String affectedID : containedIDs) {
            if (subject.equals(findById("subject_"+affectedID).getText())) {
                return affectedID;
            }
        }
        
        return null;
    }
    


}
